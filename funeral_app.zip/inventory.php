<?php
// DB connection settings
$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_name = trim($_POST['item_name'] ?? '');
    $total_qty = trim($_POST['total_qty'] ?? '');

    // Basic validation
    if (!$item_name || !is_numeric($total_qty)) {
        $error = "Please fill all fields correctly.";
    }

    if (!$error) {
        $current_qty = $total_qty; // Automatically set current_qty = total_qty
        $sql = "INSERT INTO inventory (item_name, total_qty, current_qty) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        try {
            $stmt->execute([$item_name, $total_qty, $current_qty]);
            $success = "Inventory item added successfully.";
            // Clear inputs
            $_POST = [];
        } catch (PDOException $ex) {
            $error = "Database error: " . $ex->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Add Inventory Item</title>
<style>
    body { font-family: Arial, sans-serif; background: #f0f2f5; margin: 40px; color: #333; }
    .container { max-width: 400px; background: white; padding: 30px 25px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); margin: auto; }
    h2 { text-align: center; color: #4CAF50; margin-bottom: 20px; }
    label { display: block; margin-top: 15px; font-weight: bold; }
    input[type=text], input[type=number] {
        width: 100%; padding: 10px; margin-top: 5px; border-radius: 6px; border: 1.5px solid #ccc; font-size: 1rem;
    }
    button {
        margin-top: 25px; width: 100%; background-color: #4CAF50; color: white; padding: 12px; font-size: 1.1rem;
        border: none; border-radius: 8px; cursor: pointer; font-weight: bold;
    }
    button:hover { background-color: #45a049; }
    .error { background: #f8d7da; color: #842029; padding: 10px; border-radius: 6px; margin-bottom: 15px; }
    .success { background: #d1e7dd; color: #0f5132; padding: 10px; border-radius: 6px; margin-bottom: 15px; }
</style>
</head>
<body>
<div class="container">
    <h2>Add Inventory Item</h2>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
        <label for="item_name">Item Name</label>
        <input type="text" id="item_name" name="item_name" required value="<?= htmlspecialchars($_POST['item_name'] ?? '') ?>" />

        <label for="total_qty">Total Quantity</label>
        <input type="number" id="total_qty" name="total_qty" required min="0" value="<?= htmlspecialchars($_POST['total_qty'] ?? '') ?>" />

        <button type="submit">Add Item</button>
    </form>
</div>
</body>
</html>
