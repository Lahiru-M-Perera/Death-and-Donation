<?php
require "config.php";
checkLogin();

$username = $_SESSION['username'] ?? 'User';

// Fetch stats
$total_members = $conn->query("SELECT COUNT(*) FROM members")->fetchColumn();
$active_members = $conn->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn();
$inactive_members = $conn->query("SELECT COUNT(*) FROM members WHERE status = 'inactive'")->fetchColumn();
$total_relations = $conn->query("SELECT COUNT(*) FROM relations")->fetchColumn();
$deaths_count = $conn->query("SELECT COUNT(*) FROM death")->fetchColumn();
$total_aid_given = $conn->query("SELECT COALESCE(SUM(total_amount), 0) FROM aids")->fetchColumn();
$total_fine = $conn->query("SELECT COALESCE(SUM(fine_amount), 0) FROM contributions")->fetchColumn();
$total_contrib = $conn->query("SELECT COALESCE(SUM(contribution_amount), 0) FROM contributions")->fetchColumn();

// Gender distribution
$gender_data = $conn->query("
    SELECT gender, COUNT(*) as count 
    FROM (
        SELECT gender FROM members
        UNION ALL
        SELECT gender FROM relations
    ) as all_people
    GROUP BY gender
")->fetchAll(PDO::FETCH_KEY_PAIR);

// Get list of deceased reg_no to exclude from age breakdown
$deceased_regnos = $conn->query("SELECT reg_no FROM death")->fetchAll(PDO::FETCH_COLUMN);
$deceased_list = array_map(function($v) use ($conn) {
    return $conn->quote($v);
}, $deceased_regnos);
$deceased_list_str = implode(',', $deceased_list);

// Age breakdown buckets
$age_breakdown = [
    '0-17' => 0,
    '18-29' => 0,
    '30-44' => 0,
    '45-59' => 0,
    '60+' => 0
];

// Fetch dob excluding deceased
$query_members = "SELECT dob FROM members WHERE dob IS NOT NULL";
if (!empty($deceased_list_str)) {
    $query_members .= " AND reg_no NOT IN ($deceased_list_str)";
}

$query_relations = "SELECT dob FROM relations WHERE dob IS NOT NULL";
if (!empty($deceased_list_str)) {
    $query_relations .= " AND reg_no NOT IN ($deceased_list_str)";
}

$dob_data = $conn->query($query_members . " UNION ALL " . $query_relations)->fetchAll(PDO::FETCH_COLUMN);

// Calculate age breakdown
foreach ($dob_data as $dob) {
    $age = (int) floor((time() - strtotime($dob)) / (365.25 * 24 * 60 * 60));
    if ($age <= 17) $age_breakdown['0-17']++;
    elseif ($age <= 29) $age_breakdown['18-29']++;
    elseif ($age <= 44) $age_breakdown['30-44']++;
    elseif ($age <= 59) $age_breakdown['45-59']++;
    else $age_breakdown['60+']++;
}

// Detect aid date column
$columns = $conn->query("SHOW COLUMNS FROM aids")->fetchAll(PDO::FETCH_COLUMN);
$aid_date_col = null;
if (in_array('donation_date', $columns)) {
    $aid_date_col = 'donation_date';
} else {
    foreach (['aid_date', 'date', 'created_at'] as $col_candidate) {
        if (in_array($col_candidate, $columns)) {
            $aid_date_col = $col_candidate;
            break;
        }
    }
}

// Monthly aid timeline
$aid_timeline = [];
if ($aid_date_col) {
    $stmt = $conn->query("
        SELECT DATE_FORMAT($aid_date_col, '%Y-%m') AS month, SUM(total_amount) as total_amount 
        FROM aids 
        WHERE $aid_date_col IS NOT NULL
        GROUP BY month 
        ORDER BY month ASC
    ");
    $aid_timeline = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch upcoming events (assuming table `events` with columns: id, title, description, event_date)
$events_stmt = $conn->prepare("
    SELECT id, title, description, event_date 
    FROM events 
    WHERE event_date >= CURDATE() 
    ORDER BY event_date ASC 
    LIMIT 5
");
$events_stmt->execute();
$events = $events_stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
  * { box-sizing: border-box; }
  body, html {
    margin: 0; padding: 0; height: 100%;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f0f2f5;
    color: #333;
    overflow-x: hidden;
  }
  .sidebar {
    position: fixed; top: 0; left: 0; bottom: 0;
    width: 250px;
    background: #1e1e2f;
    color: #a0a0b8;
    display: flex; flex-direction: column;
    padding-top: 20px;
    box-shadow: 2px 0 8px rgba(0,0,0,0.15);
  }
  .sidebar .logo {
    color: #4c6ef5;
    font-size: 24px;
    font-weight: 700;
    text-align: center;
    margin-bottom: 30px;
    letter-spacing: 1.5px;
    user-select: none;
  }
  .sidebar nav a {
    display: flex; align-items: center;
    padding: 14px 24px;
    color: #a0a0b8;
    font-weight: 600;
    text-decoration: none;
    border-radius: 6px;
    cursor: pointer;
    transition: background 0.3s, color 0.3s;
  }
  .sidebar nav a i {
    margin-right: 12px;
    font-size: 18px;
  }
  .sidebar nav a.active,
  .sidebar nav a:hover {
    background: #4c6ef5;
    color: white;
  }
  .sidebar nav a.has-submenu::after {
    content: "\f0d7";
    font-family: "Font Awesome 6 Free";
    font-weight: 900;
    margin-left: auto;
    transition: transform 0.3s;
  }
  .sidebar nav a.has-submenu.active::after {
    transform: rotate(180deg);
  }
  .sidebar nav .submenu {
    display: none;
    flex-direction: column;
    margin-left: 20px;
    margin-top: 6px;
  }
  .sidebar nav a.has-submenu.active + .submenu {
    display: flex;
  }
  .sidebar nav .submenu a {
    padding: 8px 24px;
    font-size: 14px;
    font-weight: 500;
    color: #b0b0c0;
  }
  .sidebar nav .submenu a:hover {
    color: #fff;
  }
  .sidebar footer {
    margin-top: auto;
    padding: 15px 24px;
    font-size: 13px;
    color: #666;
    text-align: center;
  }

  .main-content {
    margin-left: 250px;
    padding: 20px 40px 40px;
    min-height: 100vh;
    background: #fff;
  }

  .topbar {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    margin-bottom: 25px;
  }
  .topbar .user-info {
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 600;
    color: #555;
  }

  .cards {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: space-between;
  }
  .card {
    flex: 1 1 22%;
    background: #f9f9fb;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgb(76 110 245 / 0.2);
    padding: 20px 18px;
    display: flex;
    flex-direction: column;
    align-items: center;
    cursor: default;
    transition: box-shadow 0.3s ease;
  }
  .card:hover {
    box-shadow: 0 8px 20px rgb(76 110 245 / 0.35);
  }
  .card .icon {
    font-size: 28px;
    margin-bottom: 12px;
  }
  .card h2 {
    font-size: 28px;
    margin: 0;
    color: #222;
  }
  .card p {
    margin: 6px 0 0;
    color: #666;
    font-weight: 600;
  }
  .card.members { color: #4c6ef5; }
  .card.active { color: #37b24d; }
  .card.inactive { color: #f03e3e; }
  .card.relations { color: #228be6; }
  .card.deaths { color: #fa5252; }
  .card.aid { color: #15aabf; }
  .card.fine { color: #f59f00; }
  .card.contrib { color: #845ef7; }

  .charts {
    margin-top: 40px;
    display: flex;
    flex-wrap: wrap;
    gap: 36px;
    justify-content: center;
  }
  .chart-box {
    background: #f9f9fb;
    padding: 28px;
    border-radius: 14px;
    box-shadow: 0 4px 10px rgb(76 110 245 / 0.15);
    flex: 1 1 45%;
    max-width: 600px;
  }
  .chart-box h3 {
    margin: 0 0 20px 0;
    font-weight: 700;
    color: #4c6ef5;
    text-align: center;
  }

  /* Events cards styling */
  section.upcoming-events {
    margin-top: 40px;
  }
  section.upcoming-events h2 {
    color: #4c6ef5;
    margin-bottom: 20px;
    font-weight: 700;
  }
  .events-list {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: flex-start;
  }
  .event-card {
    background: #f9f9fb;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgb(76 110 245 / 0.15);
    padding: 20px 24px;
    flex: 1 1 45%;
    max-width: 350px;
    cursor: default;
    transition: box-shadow 0.3s ease;
  }
  .event-card:hover {
    box-shadow: 0 8px 20px rgb(76 110 245 / 0.35);
  }
  .event-card h3 {
    margin-top: 0;
    color: #2c3e50;
    font-weight: 700;
    font-size: 1.1rem;
  }
  .event-card p {
    color: #7f8c8d;
    font-size: 0.9rem;
    margin: 6px 0 12px;
    white-space: pre-wrap;
  }
  .event-date-badge {
    background-color: #4c6ef5;
    color: white;
    padding: 8px 14px;
    border-radius: 6px;
    font-weight: 600;
    font-size: 0.9rem;
    width: fit-content;
    user-select: none;
  }

  @media (max-width: 1024px) {
    .card { flex: 1 1 45%; }
    .charts {
      flex-direction: column;
      gap: 30px;
      align-items: center;
    }
    .event-card {
      flex: 1 1 90%;
      max-width: 100%;
    }
  }
  @media (max-width: 600px) {
    .sidebar {
      width: 70px;
      padding-top: 10px;
    }
    .sidebar .logo {
      font-size: 16px;
      margin-bottom: 20px;
      letter-spacing: normal;
    }
    .sidebar nav a span { display: none; }
    .sidebar nav a {
      justify-content: center;
      padding: 12px 0;
    }
    .main-content {
      margin-left: 70px;
      padding: 20px 20px 40px;
    }
    .cards { justify-content: center; }
    .card { flex: 1 1 90%; }
    .charts { max-width: 100%; }
  }
</style>
</head>
<body>

<div class="sidebar">
  <div class="logo">Funeral Aid app</div>
  <nav>
    <a href="#" class="active"><i class="fa-solid fa-house"></i> <span>Home</span></a>

    <a href="#" class="has-submenu"><i class="fa-solid fa-plus"></i> <span>Add Data</span></a>
    <div class="submenu">
      <a href="add_member.php">Add Member</a>
      <a href="add_relation.php">Add Relation</a>
      <a href="deaths.php">Add Death</a>
      <a href="aids.php">Add Aid</a>
    </div>

    <a href="#" class="has-submenu"><i class="fa-solid fa-plus"></i> <span>View Data</span></a>
    <div class="submenu">
      <a href="members_list.php">View Member</a>
      <a href="view_aid.php">View Aid</a>
      <a href="view_death.php">View Death</a>
      <a href="view_aid.php">View Aid</a>
    </div>

    <a href="#" class="has-submenu"><i class="fa-regular fa-calendar-days"></i> <span>Calendar</span></a>
    <div class="submenu">
      <a href="calendar.php">View Calendar</a>
      <a href="add_event.php">Add Event</a>
    </div>

    <a href="#" class="has-submenu"><i class="fa-solid fa-file-chart-column"></i> <span>Reports</span></a>
    <div class="submenu">
      <a href="reports.php">General Reports</a>
      <a href="monthly_report.php">Monthly Report</a>
    </div>

    <a href="#" class="has-submenu"><i class="fa-solid fa-user-cog"></i> <span>Account</span></a>
    <div class="submenu">
      <a href="register.php">Add Account</a>
      <a href="view_account.php">View Account</a>
    </div>

    <a href="dashboard.php"><i class="fa-solid fa-gauge"></i> <span>Dashboard</span></a>
    <a href="contacts.php"><i class="fa-solid fa-address-book"></i> <span>Contacts</span></a>
    <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> <span>Logout</span></a>
  </nav>
  <footer>&copy; <?= date('Y') ?> LAHIRU R. PERERA</footer>
</div>

<div class="main-content">
  <div class="topbar">
    <div class="user-info">
      <span><?= htmlspecialchars($username) ?></span>
    </div>
  </div>

  <div class="cards">
    <div class="card members">
      <i class="fa-solid fa-users icon"></i>
      <h2><?= $total_members ?></h2>
      <p>Total Members</p>
    </div>
    <div class="card active">
      <i class="fa-solid fa-user-check icon"></i>
      <h2><?= $active_members ?></h2>
      <p>Active Members</p>
    </div>
    <div class="card inactive">
      <i class="fa-solid fa-user-xmark icon"></i>
      <h2><?= $inactive_members ?></h2>
      <p>Inactive Members</p>
    </div>
    <div class="card relations">
      <i class="fa-solid fa-people-group icon"></i>
      <h2><?= $total_relations ?></h2>
      <p>Total Relations</p>
    </div>
    <div class="card deaths">
      <i class="fa-solid fa-cross icon"></i>
      <h2><?= $deaths_count ?></h2>
      <p>Deaths</p>
    </div>
    <div class="card aid">
      <i class="fa-solid fa-hand-holding-heart icon"></i>
      <h2>Rs. <?= number_format($total_aid_given, 2) ?></h2>
      <p>Total Aid Given</p>
    </div>
    <div class="card fine">
      <i class="fa-solid fa-money-bill-wave icon"></i>
      <h2>Rs. <?= number_format($total_fine, 2) ?></h2>
      <p>Total Fines</p>
    </div>
    <div class="card contrib">
      <i class="fa-solid fa-donate icon"></i>
      <h2>Rs. <?= number_format($total_contrib, 2) ?></h2>
      <p>Total Contributions</p>
    </div>
  </div>

  <!-- NEW EVENTS SECTION -->
  <section class="upcoming-events">
    <h2>Upcoming Events</h2>
    <div class="events-list">
      <?php if (!empty($events)): ?>
        <?php foreach ($events as $event): ?>
          <div class="event-card" 
            onmouseover="this.style.boxShadow='0 8px 20px rgb(76 110 245 / 0.35)'" 
            onmouseout="this.style.boxShadow='0 4px 6px rgb(76 110 245 / 0.15)'"
          >
            <h3><?= htmlspecialchars($event['title']) ?></h3>
            <p><?= nl2br(htmlspecialchars($event['description'])) ?></p>
            <div class="event-date-badge"><?= date('M d, Y', strtotime($event['event_date'])) ?></div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p style="color: #999; font-style: italic;">No upcoming events found.</p>
      <?php endif; ?>
    </div>
  </section>

  <div class="charts">
    <div class="chart-box">
      <h3>Gender Distribution</h3>
      <canvas id="genderChart" width="400" height="300"></canvas>
    </div>
    <div class="chart-box">
      <h3>Age Breakdown</h3>
      <canvas id="ageChart" width="400" height="300"></canvas>
    </div>
    <div class="chart-box" style="flex-basis: 100%;">
      <h3>Monthly Aid Given Timeline</h3>
      <canvas id="aidTimelineChart" width="800" height="300"></canvas>
    </div>
  </div>

</div>

<script>
  // Sidebar submenu toggle
  document.querySelectorAll('.sidebar nav a.has-submenu').forEach(el => {
    el.addEventListener('click', e => {
      e.preventDefault();
      el.classList.toggle('active');
    });
  });

  // Gender chart
  const genderCtx = document.getElementById('genderChart').getContext('2d');
  const genderData = {
    labels: [<?php
      echo '"' . implode('","', array_keys($gender_data)) . '"';
    ?>],
    datasets: [{
      label: 'Count',
      data: [<?php
        echo implode(',', array_values($gender_data));
      ?>],
      backgroundColor: [
        '#4c6ef5',
        '#15aabf',
        '#f03e3e',
        '#ff922b',
        '#37b24d',
      ],
    }]
  };
  const genderChart = new Chart(genderCtx, {
    type: 'doughnut',
    data: genderData,
    options: {
      responsive: true,
      plugins: {
        legend: { position: 'bottom' }
      }
    }
  });

  // Age chart
  const ageCtx = document.getElementById('ageChart').getContext('2d');
  const ageLabels = <?= json_encode(array_keys($age_breakdown)) ?>;
  const ageValues = <?= json_encode(array_values($age_breakdown)) ?>;
  const ageChart = new Chart(ageCtx, {
    type: 'bar',
    data: {
      labels: ageLabels,
      datasets: [{
        label: 'Count',
        data: ageValues,
        backgroundColor: '#4c6ef5',
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          ticks: { stepSize: 1 }
        }
      },
      plugins: {
        legend: { display: false }
      }
    }
  });

  // Aid timeline chart
  const aidCtx = document.getElementById('aidTimelineChart').getContext('2d');
  const aidLabels = <?= json_encode(array_column($aid_timeline, 'month')) ?>;
  const aidData = <?= json_encode(array_map(function($row){ return (float)$row['total_amount']; }, $aid_timeline)) ?>;
  const aidChart = new Chart(aidCtx, {
    type: 'line',
    data: {
      labels: aidLabels,
      datasets: [{
        label: 'Aid Given (Rs.)',
        data: aidData,
        fill: true,
        backgroundColor: 'rgba(76, 110, 245, 0.2)',
        borderColor: '#4c6ef5',
        tension: 0.3,
        pointRadius: 4,
        pointBackgroundColor: '#4c6ef5'
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true }
      },
      plugins: {
        legend: { position: 'top' }
      }
    }
  });
</script>

</body>
</html>
