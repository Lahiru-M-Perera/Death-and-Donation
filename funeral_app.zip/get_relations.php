<?php
header('Content-Type: application/json; charset=utf-8');

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode([]);
    exit;
}

$member_id = isset($_GET['member_id']) ? (int)$_GET['member_id'] : 0;
if ($member_id <= 0) {
    echo json_encode([]);
    exit;
}

// Try preferred table name: member_relations (with member_id)
try {
    $stmt = $conn->prepare("SELECT id, relation_name, COALESCE(relation_type, '') AS relation_type FROM member_relations WHERE member_id = ? ORDER BY relation_name");
    $stmt->execute([$member_id]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (!empty($rows)) {
        echo json_encode($rows);
        exit;
    }
} catch (PDOException $e) {
    // table might not exist — fall through to next attempt
}

// Fallback: try relations table (maybe linked by reg_no)
try {
    // get reg_no for this member id
    $s = $conn->prepare("SELECT reg_no FROM members WHERE id = ?");
    $s->execute([$member_id]);
    $reg_no = $s->fetchColumn();
    if ($reg_no) {
        $stmt = $conn->prepare("SELECT id, relation_name, COALESCE(relation_type, '') AS relation_type FROM relations WHERE reg_no = ? ORDER BY relation_name");
        $stmt->execute([$reg_no]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($rows)) {
            echo json_encode($rows);
            exit;
        }
    }
} catch (PDOException $e) {
    // nothing else to do
}

// nothing found
echo json_encode([]);
exit;
