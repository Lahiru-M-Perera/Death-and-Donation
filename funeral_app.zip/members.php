<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$error = "";
$success = "";

// Get last registered reg_no
$lastRegNo = "";
try {
    $stmt = $conn->query("SELECT reg_no FROM members ORDER BY id DESC LIMIT 1");
    $lastRegNo = $stmt->fetchColumn() ?: "No members yet";
} catch (PDOException $e) {
    $lastRegNo = "Error fetching last reg no";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Use null coalescing operator to avoid undefined index warnings
    $reg_no = trim($_POST['reg_no'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $dob = $_POST['dob'] ?? '';
    $nic = trim($_POST['nic'] ?? '');
    $joined_date = $_POST['joined_date'] ?? '';
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $status = trim($_POST['status'] ?? '');
    $gender = trim($_POST['gender'] ?? '');

    // Basic validation
    if (!$reg_no || !$full_name || !$address || !$dob || !$joined_date || !$phone || !$email || !$status || !$gender) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address.";
    } elseif (!preg_match('/^\d{10}$/', $phone)) {
        $error = "Phone number must be exactly 10 digits.";
    }

    // Handle photo upload if no validation error yet
    $photo_filename = null;
    if (!$error && isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $allowed_ext = ['jpg','jpeg','png','gif'];
            $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, $allowed_ext)) {
                $upload_dir = __DIR__ . '/uploads/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
                $photo_filename = uniqid('photo_', true) . '.' . $ext;
                $target_file = $upload_dir . $photo_filename;
                if (!move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
                    $error = "Failed to upload photo.";
                }
            } else {
                $error = "Invalid photo file type. Allowed types: jpg, jpeg, png, gif.";
            }
        } else {
            $error = "Error uploading photo (code: {$_FILES['photo']['error']}).";
        }
    }

    // Insert into DB if no error
    if (!$error) {
        $sql = "INSERT INTO members (reg_no, full_name, address, dob, nic, joined_date, phone, photo, email, status, gender)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        try {
            $stmt->execute([$reg_no, $full_name, $address, $dob, $nic, $joined_date, $phone, $photo_filename, $email, $status, $gender]);
            $success = "Member added successfully!";
            $lastRegNo = $reg_no;
            // Clear POST to reset form
            $_POST = [];
        } catch (PDOException $ex) {
            $error = "Database error: " . $ex->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Add Member</title>
<style>
    /* Your original CSS unchanged */
    /* Reset */
    * {
        box-sizing: border-box;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f8f9fb;
        margin: 0;
        padding: 0;
        color: #333;
    }

    /* Header / Navbar */
    header {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: #2c7be5;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 30px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.15);
        z-index: 1000;
    }

    header .nav-links a {
        color: #cfe2ff;
        text-decoration: none;
        margin-left: 20px;
        font-weight: 600;
        font-size: 1rem;
        transition: color 0.3s ease;
    }

    header .nav-links a:hover {
        color: #a2c4f7;
    }

    header .last-reg {
        font-size: 0.95rem;
        font-weight: 600;
    }

    /* Main container */
    .container {
        max-width: 700px;
        background: #fff;
        margin: 90px auto 40px;
        padding: 30px 40px;
        border-radius: 10px;
        box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }

    h2 {
        text-align: center;
        margin-bottom: 25px;
        font-weight: 700;
        color: #2c7be5;
        letter-spacing: 1px;
    }

    label {
        display: block;
        margin-top: 18px;
        font-weight: 600;
        color: #555;
    }

    input[type="text"],
    input[type="email"],
    input[type="date"],
    input[type="tel"],
    select,
    textarea {
        width: 100%;
        padding: 10px 14px;
        margin-top: 6px;
        border-radius: 6px;
        border: 1.8px solid #ccc;
        font-size: 1rem;
        font-family: inherit;
        transition: border-color 0.3s ease;
    }

    input[type="text"]:focus,
    input[type="email"]:focus,
    input[type="date"]:focus,
    input[type="tel"]:focus,
    select:focus,
    textarea:focus {
        border-color: #2c7be5;
        outline: none;
        box-shadow: 0 0 6px rgba(44,123,229,0.4);
    }

    textarea {
        resize: vertical;
        min-height: 70px;
    }

    button {
        margin-top: 30px;
        width: 100%;
        padding: 14px 0;
        background-color: #2c7be5;
        color: white;
        font-size: 18px;
        font-weight: 700;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    button:hover {
        background-color: #1a5fd3;
    }

    /* Alert boxes */
    .error, .success {
        margin-bottom: 20px;
        padding: 12px 18px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 1rem;
        text-align: center;
        user-select: none;
    }

    .error {
        background-color: #ffe5e5;
        color: #cc0000;
        border: 1px solid #cc0000;
    }

    .success {
        background-color: #d6f5d6;
        color: #2d662d;
        border: 1px solid #2d662d;
    }

    /* Responsive */
    @media(max-width: 480px) {
        .container {
            margin: 100px 15px 40px;
            padding: 20px 25px;
        }
        header {
            flex-direction: column;
            align-items: flex-start;
            padding: 12px 15px;
        }
        header .nav-links {                    
            margin-top: 8px;
        }
        header .nav-links a {
            margin-left: 0;
            margin-right: 15px;
        }
    }
</style>
</head>
<body>
<header>
    <div class="last-reg">Last Registered No: <?= htmlspecialchars($lastRegNo) ?></div>
    <nav class="nav-links">
        <a href="dashboard.php" title="Go to Dashboard">Dashboard</a>
        <a href="relations.php" title="Go to Relations">Relations</a>
        <a href="members_list.php" title="View Members List">Members List</a>
    </nav>
</header>

<div class="container">
    <h2>Add New Member</h2>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" novalidate>
        <label for="reg_no">Registration Number</label>
        <input type="text" name="reg_no" id="reg_no" required placeholder="e.g. REG1234"
            value="<?= htmlspecialchars($_POST['reg_no'] ?? '') ?>" />

        <label for="full_name">Full Name</label>
        <input type="text" name="full_name" id="full_name" required placeholder="Full member name"
            value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" />

        <label for="address">Address</label>
        <textarea name="address" id="address" rows="3" required placeholder="Member's address"><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>

        <label for="dob">Date of Birth</label>
        <input type="date" name="dob" id="dob" required value="<?= htmlspecialchars($_POST['dob'] ?? '') ?>" />

        <label for="nic">NIC</label>
        <input type="text" name="nic" id="nic" maxlength="12" placeholder="National ID Number"
            value="<?= htmlspecialchars($_POST['nic'] ?? '') ?>" />

        <label for="joined_date">Joined Date</label>
        <input type="date" name="joined_date" id="joined_date" required
            value="<?= htmlspecialchars($_POST['joined_date'] ?? '') ?>" />

        <label for="phone">Phone Number</label>
        <input type="tel" name="phone" id="phone" pattern="[0-9]{10}" required placeholder="10 digit number"
            value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" />

        <label for="gender">Gender</label>
        <select name="gender" id="gender" required>
            <option value="" disabled <?= empty($_POST['gender']) ? 'selected' : '' ?>>Select Gender</option>
            <option value="Male" <?= (($_POST['gender'] ?? '') === 'Male') ? 'selected' : '' ?>>Male</option>
            <option value="Female" <?= (($_POST['gender'] ?? '') === 'Female') ? 'selected' : '' ?>>Female</option>
            <option value="Other" <?= (($_POST['gender'] ?? '') === 'Other') ? 'selected' : '' ?>>Other</option>
        </select>

        <label for="photo">Photo</label>
        <input type="file" name="photo" id="photo" accept="image/*" />

        <label for="email">Email</label>
        <input type="email" name="email" id="email" required placeholder="Email address"
            value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" />

        <label for="status">Status</label>
        <select name="status" id="status" required>
            <option value="" disabled <?= empty($_POST['status']) ? 'selected' : '' ?>>Select status</option>
            <option value="active" <?= (($_POST['status'] ?? '') === 'active') ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= (($_POST['status'] ?? '') === 'inactive') ? 'selected' : '' ?>>Inactive</option>
            <option value="deceased" <?= (($_POST['status'] ?? '') === 'deceased') ? 'selected' : '' ?>>Deceased</option>
        </select>

        <button type="submit">Add Member</button>
    </form>
</div>
</body>
</html>
