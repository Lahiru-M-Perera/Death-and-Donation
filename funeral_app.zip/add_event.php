<?php
require "config.php";
checkLogin();

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $event_date = $_POST['event_date'] ?? '';

    if ($title === '' || $event_date === '') {
        $message = 'Please enter both Title and Event Date.';
    } else {
        // Insert event into database
        $stmt = $conn->prepare("INSERT INTO events (title, description, event_date) VALUES (:title, :description, :event_date)");
        try {
            $stmt->execute([
                ':title' => $title,
                ':description' => $description,
                ':event_date' => $event_date
            ]);
            $message = "Event added successfully!";
        } catch (PDOException $e) {
            $message = "Error adding event: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Add Event</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background: #f0f2f5;
    padding: 20px;
  }
  .container {
    max-width: 480px;
    margin: 0 auto;
    background: #fff;
    padding: 24px 32px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  }
  h2 {
    margin-bottom: 24px;
    color: #4c6ef5;
  }
  label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
  }
  input[type="text"],
  input[type="date"],
  textarea {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 18px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 16px;
    resize: vertical;
  }
  button {
    background: #4c6ef5;
    color: white;
    border: none;
    padding: 12px 20px;
    font-size: 16px;
    border-radius: 6px;
    cursor: pointer;
    transition: background 0.3s ease;
  }
  button:hover {
    background: #3b57d4;
  }
  .message {
    margin-bottom: 18px;
    font-weight: 600;
    color: #d6336c;
  }
  .success {
    color: #37b24d;
  }
  a {
    display: inline-block;
    margin-top: 14px;
    text-decoration: none;
    color: #4c6ef5;
  }
  a:hover {
    text-decoration: underline;
  }
</style>
</head>
<body>

<div class="container">
  <h2>Add New Event</h2>

  <?php if ($message): ?>
    <div class="message <?= strpos($message, 'successfully') !== false ? 'success' : '' ?>">
      <?= htmlspecialchars($message) ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="">
    <label for="title">Event Title <sup style="color:red">*</sup></label>
    <input type="text" id="title" name="title" required maxlength="255" value="<?= htmlspecialchars($_POST['title'] ?? '') ?>" />

    <label for="description">Description</label>
    <textarea id="description" name="description" rows="4"><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>

    <label for="event_date">Event Date <sup style="color:red">*</sup></label>
    <input type="date" id="event_date" name="event_date" required value="<?= htmlspecialchars($_POST['event_date'] ?? '') ?>" />

    <button type="submit">Add Event</button>
  </form>

  <a href="dashboard.php">← Back to Dashboard</a>
</div>

</body>
</html>
