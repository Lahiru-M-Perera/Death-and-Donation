<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

if (!isset($_GET['reg_no'])) {
    die("No member registration number specified. Use ?reg_no=XXXX in the URL.");
}
$reg_no = $_GET['reg_no'];

$messages = ['success' => [], 'error' => []];

// ===== Member update =====
if (isset($_POST['update_member'])) {
    $full_name = trim($_POST['full_name'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $dob = $_POST['dob'] ?? null;
    $nic = trim($_POST['nic'] ?? '');
    $joined_date = $_POST['joined_date'] ?? null;
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $status = trim($_POST['status'] ?? 'active');
    $gender = trim($_POST['gender'] ?? '');

    if ($full_name === '') {
        $messages['error'][] = 'Full name is required.';
    }
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $messages['error'][] = 'Invalid email address.';
    }

    if (empty($messages['error'])) {
        $sql = "UPDATE members SET full_name=?, address=?, dob=?, nic=?, joined_date=?, phone=?, email=?, status=?, gender=? WHERE reg_no=?";
        $stmt = $conn->prepare($sql);
        try {
            $stmt->execute([$full_name, $address, $dob, $nic, $joined_date, $phone, $email, $status, $gender, $reg_no]);
            $messages['success'][] = "Member details updated successfully.";
        } catch (PDOException $ex) {
            $messages['error'][] = "Member update failed: " . $ex->getMessage();
        }
    }
}

// ===== Relation update =====
if (isset($_POST['update_relation'])) {
    $relation_id = (int)($_POST['relation_id'] ?? 0);
    $full_name_r = trim($_POST['relation_full_name'] ?? '');
    $address_r = trim($_POST['relation_address'] ?? '');
    $dob_r = $_POST['relation_dob'] ?? null;
    $nic_r = trim($_POST['relation_nic'] ?? '');
    $phone_r = trim($_POST['relation_phone'] ?? '');
    $relation_type = trim($_POST['relation_type'] ?? 'Other');
    $gender_r = trim($_POST['relation_gender'] ?? '');

    if ($relation_id <= 0) {
        $messages['error'][] = 'Invalid relation id.';
    }

    if (empty($messages['error'])) {
        $sql = "UPDATE relations SET full_name=?, address=?, dob=?, nic=?, phone=?, relation_type=?, gender=? WHERE id=? AND reg_no=?";
        $stmt = $conn->prepare($sql);
        try {
            $stmt->execute([$full_name_r, $address_r, $dob_r, $nic_r, $phone_r, $relation_type, $gender_r, $relation_id, $reg_no]);
            $messages['success'][] = "Relation updated successfully.";
        } catch (PDOException $ex) {
            $messages['error'][] = "Relation update failed: " . $ex->getMessage();
        }
    }
}

// ===== Delete relation =====
if (isset($_POST['delete_relation'])) {
    $relation_id = (int)($_POST['relation_id'] ?? 0);
    if ($relation_id > 0) {
        $sql = "DELETE FROM relations WHERE id=? AND reg_no=?";
        $stmt = $conn->prepare($sql);
        try {
            $stmt->execute([$relation_id, $reg_no]);
            $messages['success'][] = "Relation deleted successfully.";
        } catch (PDOException $ex) {
            $messages['error'][] = "Failed to delete relation: " . $ex->getMessage();
        }
    } else {
        $messages['error'][] = "Invalid relation id for deletion.";
    }
}

// ===== Add relation =====
if (isset($_POST['add_relation'])) {
    $full_name_r = trim($_POST['new_relation_full_name'] ?? '');
    $address_r = trim($_POST['new_relation_address'] ?? '');
    $dob_r = $_POST['new_relation_dob'] ?? null;
    $nic_r = trim($_POST['new_relation_nic'] ?? '');
    $phone_r = trim($_POST['new_relation_phone'] ?? '');
    $relation_type = trim($_POST['new_relation_type'] ?? 'Other');
    $gender_r = trim($_POST['new_relation_gender'] ?? '');

    if ($full_name_r === '') {
        $messages['error'][] = 'Relation full name is required.';
    }

    if (empty($messages['error'])) {
        $sql = "INSERT INTO relations (reg_no, full_name, address, dob, nic, phone, relation_type, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        try {
            $stmt->execute([$reg_no, $full_name_r, $address_r, $dob_r, $nic_r, $phone_r, $relation_type, $gender_r]);
            $messages['success'][] = "New relation added successfully.";
        } catch (PDOException $ex) {
            $messages['error'][] = "Failed to add relation: " . $ex->getMessage();
        }
    }
}

// Fetch member & relations
$stmt = $conn->prepare("SELECT * FROM members WHERE reg_no = ?");
$stmt->execute([$reg_no]);
$member = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$member) {
    die("Member not found.");
}

$stmt = $conn->prepare("SELECT * FROM relations WHERE reg_no = ? ORDER BY id DESC");
$stmt->execute([$reg_no]);
$relations = $stmt->fetchAll(PDO::FETCH_ASSOC);

function e($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Member & Relations — Professional UI</title>
<link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
<style>
  :root {
    --primary: #1565c0;
    --primary-light: #5e92f3;
    --primary-dark: #003c8f;
    --bg: #f5faff;
    --card-bg: #fff;
    --text-primary: #0d1a36;
    --text-muted: #556987;
    --border: #cbd6e2;
    --error: #d32f2f;
    --success: #388e3c;
  }
  * {
    box-sizing: border-box;
  }
  body {
    font-family: 'Inter', sans-serif;
    background: var(--bg);
    margin: 0;
    padding: 0;
    color: var(--text-primary);
  }
  a {
    color: var(--card-bg);
    text-decoration: none;
  }
  /* NAVBAR */
  nav {
    position: fixed;
    top: 0; left: 0; right: 0;
    height: 56px;
    background: var(--primary);
    color: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 24px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.15);
    z-index: 9999;
  }
  nav .logo {
    font-weight: 700;
    font-size: 1.3rem;
    letter-spacing: 1px;
  }
  nav ul {
    display: flex;
    align-items: center;
    gap: 18px;
    list-style: none;
    margin: 0;
    padding: 0;
  }
  nav ul li {
    font-size: 1rem;
  }
  nav ul li a {
    color: white;
    display: flex;
    align-items: center;
    gap: 4px;
  }
  nav ul li a:hover {
    text-decoration: underline;
  }
  nav .material-icons {
    font-size: 20px;
  }
  /* PAGE CONTAINER */
  .container {
    max-width: 1200px;
    margin: 80px auto 40px; /* margin-top to account for fixed nav */
    display: grid;
    grid-template-columns: 1fr 320px;
    gap: 24px;
    padding: 0 24px;
  }
  main {
    background: var(--card-bg);
    padding: 24px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(21, 101, 192, 0.15);
  }
  aside {
    background: var(--card-bg);
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 16px rgba(21, 101, 192, 0.1);
    font-size: 0.95rem;
    color: var(--text-muted);
  }
  h1, h2, h3 {
    margin-top: 0;
    color: var(--primary-dark);
  }
  h2 {
    margin-bottom: 16px;
  }
  .msg {
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
  }
  .msg-success {
    background: #e6f4ea;
    color: var(--success);
    border: 1px solid var(--success);
  }
  .msg-error {
    background: #fdecea;
    color: var(--error);
    border: 1px solid var(--error);
  }
  /* Member Section */
  .member-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }
  .member-info {
    background: var(--bg);
    padding: 18px;
    border-radius: 10px;
    border: 1px solid var(--border);
  }
  .member-info strong {
    font-size: 1.4rem;
    color: var(--primary-dark);
  }
  .member-stats {
    margin-top: 4px;
    font-size: 0.9rem;
    color: var(--text-muted);
  }
  button.btn {
    background: var(--primary);
    border: none;
    color: #fff;
    font-weight: 600;
    padding: 10px 16px;
    border-radius: 8px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 1rem;
    transition: background 0.25s ease;
  }
  button.btn:hover {
    background: var(--primary-dark);
  }
  button.btn-secondary {
    background: #e0e0e0;
    color: var(--text-primary);
  }
  button.btn-secondary:hover {
    background: #bdbdbd;
  }
  /* Collapsible forms */
  .collapsible {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease, padding 0.3s ease;
    border-radius: 8px;
    border: 1px solid var(--border);
    margin-top: 16px;
    padding: 0 16px;
    background: #f9fbff;
  }
  .collapsible.open {
    max-height: 1500px; /* big enough */
    padding: 16px;
  }
  /* Form fields */
  label.field-label {
    display: block;
    font-weight: 600;
    margin: 14px 0 6px;
    color: var(--primary-dark);
  }
  input[type=text], input[type=email], input[type=date], select, textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid var(--border);
    border-radius: 6px;
    font-size: 1rem;
    font-family: inherit;
    color: var(--text-primary);
  }
  textarea {
    min-height: 70px;
    resize: vertical;
  }
  /* Form actions */
  .form-actions {
    margin-top: 20px;
    display: flex;
    gap: 12px;
  }
  /* Relations Section */
  .relations-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 16px;
  }
  article.relation-card {
    background: var(--bg);
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(21, 101, 192, 0.1);
    padding: 18px;
    border: 1px solid var(--border);
    display: flex;
    flex-direction: column;
  }
  .relation-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 700;
    font-size: 1.1rem;
    color: var(--primary-dark);
  }
  .icon-btn {
    background: transparent;
    border: none;
    cursor: pointer;
    color: var(--primary);
    font-size: 24px;
    padding: 4px 6px;
    border-radius: 6px;
    transition: background 0.2s ease;
  }
  .icon-btn:hover {
    background: var(--primary-light);
    color: #fff;
  }
  .icon-btn.delete:hover {
    background: #d32f2f;
    color: #fff;
  }
  /* Recommendations */
  aside h2 {
    border-bottom: 2px solid var(--primary);
    padding-bottom: 6px;
  }
  aside ul {
    padding-left: 18px;
  }
  aside ul li {
    margin-bottom: 8px;
  }
  /* Responsive */
  @media (max-width: 900px) {
    .container {
      grid-template-columns: 1fr;
      margin: 100px 16px 40px;
      padding: 0 16px;
    }
    aside {
      margin-top: 24px;
    }
    nav ul {
      gap: 12px;
      font-size: 0.9rem;
    }
  }
</style>
</head>
<body>

<nav role="navigation" aria-label="Primary navigation">
  <div class="logo">Funeral Management</div>
  <ul>
    <li><a href="dashboard.php" title="Dashboard"><span class="material-icons">dashboard</span> Dashboard</a></li>
    <li><a href="members_list.php" title="Members List"><span class="material-icons">groups</span> Members</a></li>
    <li><a href="members.php" title="Add New Member"><span class="material-icons">person_add</span> Add Member</a></li>
    <li><a href="logout.php" title="Logout"><span class="material-icons">logout</span> Logout</a></li>
  </ul>
</nav>

<div class="container" role="main">
  <main>
    <?php if (!empty($messages['success'])): ?>
      <div class="msg msg-success" role="alert">
        <ul>
          <?php foreach ($messages['success'] as $m) echo '<li>' . e($m) . '</li>'; ?>
        </ul>
      </div>
    <?php endif; ?>
    <?php if (!empty($messages['error'])): ?>
      <div class="msg msg-error" role="alert">
        <ul>
          <?php foreach ($messages['error'] as $m) echo '<li>' . e($m) . '</li>'; ?>
        </ul>
      </div>
    <?php endif; ?>

    <!-- MEMBER SECTION -->
    <section aria-labelledby="member-title">
      <div class="member-header">
        <h1 id="member-title">Member Details (Reg. No: <?= e($member['reg_no']) ?>)</h1>
        <button class="btn" type="button" onclick="toggleEdit('form-member')" aria-expanded="false" aria-controls="form-member">
          <span class="material-icons">edit</span> Edit Member
        </button>
      </div>
      <div class="member-info">
        <strong><?= e($member['full_name']) ?></strong>
        <div class="member-stats">
          Status: <?= e(ucfirst($member['status'])) ?> | Joined: <?= e($member['joined_date']) ?> | Phone: <?= e($member['phone']) ?> | Email: <?= e($member['email']) ?>
        </div>
        <div>Address: <?= e($member['address']) ?></div>
      </div>

      <div id="form-member" class="collapsible" aria-hidden="true">
        <form method="POST" novalidate>
          <input type="hidden" name="update_member" value="1" />
          <label class="field-label" for="full_name">Full Name</label>
          <input type="text" id="full_name" name="full_name" value="<?= e($member['full_name']) ?>" required />

          <label class="field-label" for="address">Address</label>
          <textarea id="address" name="address"><?= e($member['address']) ?></textarea>

          <label class="field-label" for="dob">Date of Birth</label>
          <input type="date" id="dob" name="dob" value="<?= e($member['dob']) ?>" />

          <label class="field-label" for="nic">NIC</label>
          <input type="text" id="nic" name="nic" value="<?= e($member['nic']) ?>" />

          <label class="field-label" for="joined_date">Joined Date</label>
          <input type="date" id="joined_date" name="joined_date" value="<?= e($member['joined_date']) ?>" />

          <label class="field-label" for="phone">Phone</label>
          <input type="text" id="phone" name="phone" value="<?= e($member['phone']) ?>" />

          <label class="field-label" for="email">Email</label>
          <input type="email" id="email" name="email" value="<?= e($member['email']) ?>" />

          <label class="field-label" for="status">Status</label>
          <select id="status" name="status">
            <option value="active" <?= $member['status'] === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= $member['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
          </select>

          <label class="field-label" for="gender">Gender</label>
          <select id="gender" name="gender">
            <option value="" <?= $member['gender'] === '' ? 'selected' : '' ?>>Select</option>
            <option value="Male" <?= $member['gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
            <option value="Female" <?= $member['gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
            <option value="Other" <?= $member['gender'] === 'Other' ? 'selected' : '' ?>>Other</option>
          </select>

          <div class="form-actions">
            <button type="submit" class="btn">Save Member</button>
            <button type="button" class="btn btn-secondary" onclick="toggleEdit('form-member')">Cancel</button>
          </div>
        </form>
      </div>
    </section>

    <!-- RELATIONS SECTION -->
    <section aria-labelledby="relations-title" style="margin-top: 40px;">
      <h2 id="relations-title">Relations</h2>
      <div class="relations-list">
        <?php if (empty($relations)): ?>
          <p>No relations recorded.</p>
        <?php else: ?>
          <?php foreach($relations as $rel): ?>
          <article class="relation-card" aria-label="Relation <?= e($rel['full_name']) ?>">
            <div class="relation-header">
              <span><?= e($rel['full_name']) ?></span>
              <div>
                <button class="icon-btn" aria-label="Edit relation <?= e($rel['full_name']) ?>" onclick="toggleEdit('rel-<?= e($rel['id']) ?>')">
                  <span class="material-icons">edit</span>
                </button>
                <form method="POST" style="display:inline" onsubmit="return confirm('Delete this relation?');">
                  <input type="hidden" name="relation_id" value="<?= e($rel['id']) ?>" />
                  <input type="hidden" name="delete_relation" value="1" />
                  <button type="submit" class="icon-btn delete" aria-label="Delete relation <?= e($rel['full_name']) ?>">
                    <span class="material-icons">delete</span>
                  </button>
                </form>
              </div>
            </div>
            <div>
              <strong>Relation Type:</strong> <?= e($rel['relation_type']) ?><br />
              <strong>Phone:</strong> <?= e($rel['phone']) ?><br />
              <strong>Address:</strong> <?= e($rel['address']) ?>
            </div>

            <div id="rel-<?= e($rel['id']) ?>" class="collapsible" aria-hidden="true" style="margin-top: 12px;">
              <form method="POST" novalidate>
                <input type="hidden" name="update_relation" value="1" />
                <input type="hidden" name="relation_id" value="<?= e($rel['id']) ?>" />

                <label class="field-label" for="relation_full_name_<?= e($rel['id']) ?>">Full Name</label>
                <input type="text" id="relation_full_name_<?= e($rel['id']) ?>" name="relation_full_name" value="<?= e($rel['full_name']) ?>" required />

                <label class="field-label" for="relation_address_<?= e($rel['id']) ?>">Address</label>
                <textarea id="relation_address_<?= e($rel['id']) ?>" name="relation_address"><?= e($rel['address']) ?></textarea>

                <label class="field-label" for="relation_dob_<?= e($rel['id']) ?>">Date of Birth</label>
                <input type="date" id="relation_dob_<?= e($rel['id']) ?>" name="relation_dob" value="<?= e($rel['dob']) ?>" />

                <label class="field-label" for="relation_nic_<?= e($rel['id']) ?>">NIC</label>
                <input type="text" id="relation_nic_<?= e($rel['id']) ?>" name="relation_nic" value="<?= e($rel['nic']) ?>" />

                <label class="field-label" for="relation_phone_<?= e($rel['id']) ?>">Phone</label>
                <input type="text" id="relation_phone_<?= e($rel['id']) ?>" name="relation_phone" value="<?= e($rel['phone']) ?>" />

                <label class="field-label" for="relation_type_<?= e($rel['id']) ?>">Relation Type</label>
                <select id="relation_type_<?= e($rel['id']) ?>" name="relation_type">
                  <option value="Spouse" <?= $rel['relation_type'] === 'Spouse' ? 'selected' : '' ?>>Spouse</option>
                  <option value="Child" <?= $rel['relation_type'] === 'Child' ? 'selected' : '' ?>>Child</option>
                  <option value="Parent" <?= $rel['relation_type'] === 'Parent' ? 'selected' : '' ?>>Parent</option>
                  <option value="Sibling" <?= $rel['relation_type'] === 'Sibling' ? 'selected' : '' ?>>Sibling</option>
                  <option value="Other" <?= $rel['relation_type'] === 'Other' ? 'selected' : '' ?>>Other</option>
                </select>

                <label class="field-label" for="relation_gender_<?= e($rel['id']) ?>">Gender</label>
                <select id="relation_gender_<?= e($rel['id']) ?>" name="relation_gender">
                  <option value="" <?= $rel['gender'] === '' ? 'selected' : '' ?>>Select</option>
                  <option value="Male" <?= $rel['gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
                  <option value="Female" <?= $rel['gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
                  <option value="Other" <?= $rel['gender'] === 'Other' ? 'selected' : '' ?>>Other</option>
                </select>

                <div class="form-actions">
                  <button type="submit" class="btn">Save Relation</button>
                  <button type="button" class="btn btn-secondary" onclick="toggleEdit('rel-<?= e($rel['id']) ?>')">Cancel</button>
                </div>
              </form>
            </div>
          </article>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <!-- Add new relation form -->
      <button class="btn" type="button" style="margin-top: 24px;" onclick="toggleEdit('form-add-relation')">
        <span class="material-icons">person_add</span> Add New Relation
      </button>
      <div id="form-add-relation" class="collapsible" aria-hidden="true" style="margin-top: 12px;">
        <form method="POST" novalidate>
          <input type="hidden" name="add_relation" value="1" />

          <label class="field-label" for="new_relation_full_name">Full Name</label>
          <input type="text" id="new_relation_full_name" name="new_relation_full_name" required />

          <label class="field-label" for="new_relation_address">Address</label>
          <textarea id="new_relation_address" name="new_relation_address"></textarea>

          <label class="field-label" for="new_relation_dob">Date of Birth</label>
          <input type="date" id="new_relation_dob" name="new_relation_dob" />

          <label class="field-label" for="new_relation_nic">NIC</label>
          <input type="text" id="new_relation_nic" name="new_relation_nic" />

          <label class="field-label" for="new_relation_phone">Phone</label>
          <input type="text" id="new_relation_phone" name="new_relation_phone" />

          <label class="field-label" for="new_relation_type">Relation Type</label>
          <select id="new_relation_type" name="new_relation_type">
            <option value="Spouse">Spouse</option>
            <option value="Child">Child</option>
            <option value="Parent">Parent</option>
            <option value="Sibling">Sibling</option>
            <option value="Other" selected>Other</option>
          </select>

          <label class="field-label" for="new_relation_gender">Gender</label>
          <select id="new_relation_gender" name="new_relation_gender">
            <option value="" selected>Select</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>

          <div class="form-actions">
            <button type="submit" class="btn">Add Relation</button>
            <button type="button" class="btn btn-secondary" onclick="toggleEdit('form-add-relation')">Cancel</button>
          </div>
        </form>
      </div>

    </section>
  </main>

  <aside>
    <h2>Tips & Suggestions</h2>
    <ul>
      <li>Use the <span class="material-icons" style="font-size:16px;vertical-align:middle;">edit</span> button to edit details.</li>
      <li>Click the <span class="material-icons" style="font-size:16px;vertical-align:middle;">delete</span> button to remove a relation (confirm prompt).</li>
      <li>Fill all required fields when adding or editing.</li>
      <li>Ensure email addresses are valid for contact.</li>
    </ul>
  </aside>
</div>

<script>
function toggleEdit(formId) {
  const form = document.getElementById(formId);
  if (!form) return;
  const isOpen = form.classList.contains('open');
  if (isOpen) {
    form.classList.remove('open');
    form.setAttribute('aria-hidden', 'true');
  } else {
    form.classList.add('open');
    form.setAttribute('aria-hidden', 'false');
    form.scrollIntoView({behavior: 'smooth', block: 'center'});
  }
}
</script>

</body>
</html>
