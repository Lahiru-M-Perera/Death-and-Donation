<?php
session_start();

// DB Connection
$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$error = "";
$success = "";

// Fetch deaths for dropdown
$deaths = $conn->query("
    SELECT d.id, d.person_name, d.reg_no, d.date_of_death, m.full_name AS member_name, m.nic AS member_nic
    FROM death d
    LEFT JOIN members m ON d.reg_no = m.reg_no
    ORDER BY d.date_of_death DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Fetch members (donors) for dropdown
$members = $conn->query("SELECT id, full_name, reg_no FROM members ORDER BY full_name")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donor_id = $_POST['donor_id'] ?? '';
    $death_id = $_POST['death_id'] ?? '';
    $total_amount = floatval($_POST['total_amount'] ?? 0);
    $donation_date = $_POST['donation_date'] ?? date('Y-m-d');
    $notes = trim($_POST['notes'] ?? '');

    if (!$donor_id) {
        $error = "Please select a donor member.";
    } elseif (!$death_id) {
        $error = "Please select a deceased person.";
    } elseif ($total_amount <= 0) {
        $error = "Please enter a valid total aid amount.";
    } else {
        try {
            // Check if aid record exists for this death
            $stmt = $conn->prepare("SELECT id FROM aids WHERE death_id = ?");
            $stmt->execute([$death_id]);
            $aid_id = $stmt->fetchColumn();

            if ($aid_id) {
                // Update existing aid record
                $update = $conn->prepare("UPDATE aids SET donor_id = ?, total_amount = ?, donation_date = ?, notes = ? WHERE id = ?");
                $update->execute([$donor_id, $total_amount, $donation_date, $notes, $aid_id]);
            } else {
                // Insert new aid record
                $insert = $conn->prepare("INSERT INTO aids (donor_id, death_id, total_amount, donation_date, notes) VALUES (?, ?, ?, ?, ?)");
                $insert->execute([$donor_id, $death_id, $total_amount, $donation_date, $notes]);
            }

            $success = "Aid record saved successfully.";
        } catch (Exception $ex) {
            $error = "Error saving aid record: " . $ex->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Add Aid Record</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f9fafb;
    max-width: 700px;
    margin: auto;
    padding: 20px;
}
h1 { text-align: center; color: #007bff; }
form {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
label { margin-top: 10px; display: block; }
input, select, textarea {
    width: 100%;
    padding: 8px;
    margin-top: 4px;
    border: 1px solid #ccc;
    border-radius: 6px;
    box-sizing: border-box;
}
button {
    margin-top: 15px;
    background: #007bff;
    color: white;
    padding: 12px;
    border: none;
    border-radius: 6px;
    font-size: 1rem;
    cursor: pointer;
}
button:hover { background: #0056b3; }
.error, .success {
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 6px;
    font-weight: bold;
}
.error { background: #ffe5e5; color: #cc0000; }
.success { background: #d6f5d6; color: #2d662d; }
</style>
</head>
<body>

<h1>Add Aid Record</h1>

<?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST">
    <label for="donor_id">Select Donor (Member) *</label>
    <select name="donor_id" id="donor_id" required>
        <option value="" disabled selected>-- Select Donor --</option>
        <?php foreach ($members as $member): ?>
            <option value="<?= htmlspecialchars($member['id']) ?>">
                <?= htmlspecialchars($member['full_name'] . " (" . $member['reg_no'] . ")") ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="death_id">Select Deceased Person *</label>
    <select name="death_id" id="death_id" required>
        <option value="" disabled selected>-- Select Deceased Person --</option>
        <?php foreach ($deaths as $death): ?>
            <option value="<?= htmlspecialchars($death['id']) ?>">
                <?= htmlspecialchars($death['person_name'] . " (Member NIC: " . ($death['member_nic'] ?? 'N/A') . ") - Date of Death: " . $death['date_of_death']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="total_amount">Total Aid Amount (LKR) *</label>
    <input type="number" step="0.01" min="0" name="total_amount" id="total_amount" required />

    <label for="donation_date">Date of Aid *</label>
    <input type="date" name="donation_date" id="donation_date" value="<?= date('Y-m-d') ?>" required />

    <label for="notes">Notes</label>
    <textarea name="notes" id="notes" rows="3"></textarea>

    <button type="submit">Save Aid Record</button>
</form>

</body>
</html>
