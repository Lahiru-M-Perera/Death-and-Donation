<?php
date_default_timezone_set('Asia/Colombo');  // Set timezone to Sri Lanka
require "config.php";
checkLogin();

$username = $_SESSION['username'] ?? 'User';

$year = date('Y');
$month = date('m');

// Fetch events for this month
$stmt = $conn->prepare("SELECT event_date, description FROM events WHERE YEAR(event_date) = ? AND MONTH(event_date) = ?");
$stmt->execute([$year, $month]);
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

$events_by_date = [];
foreach ($events as $e) {
    $events_by_date[$e['event_date']][] = $e['event_desc'];
}

function generateCalendar($year, $month, $events_by_date) {
    $first_day = strtotime("$year-$month-01");
    $days_in_month = date('t', $first_day);
    $start_day = date('N', $first_day); // 1 (Mon) to 7 (Sun)
    
    $calendar = [];
    $week = [];

    // Fill empty days before first day
    for ($i=1; $i < $start_day; $i++) {
        $week[] = null;
    }
    for ($day=1; $day <= $days_in_month; $day++) {
        $date_str = sprintf("%04d-%02d-%02d", $year, $month, $day);
        $week[] = ['day' => $day, 'events' => $events_by_date[$date_str] ?? []];
        if (count($week) == 7) {
            $calendar[] = $week;
            $week = [];
        }
    }
    if (count($week) > 0) {
        while (count($week) < 7) $week[] = null;
        $calendar[] = $week;
    }
    return $calendar;
}

$calendar = generateCalendar($year, $month, $events_by_date);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Calendar - Funeral Aid App</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<style>
  /* Reset */
  * {
    box-sizing: border-box;
  }
  body, html {
    margin: 0; padding: 0; height: 100%;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f4f6f9;
    color: #222;
    overflow-x: hidden;
  }
  /* Sidebar */
  .sidebar {
    position: fixed;
    top: 0; left: 0; bottom: 0;
    width: 250px;
    background: #1e1e2f;
    color: #a0a0b8;
    padding-top: 20px;
    display: flex;
    flex-direction: column;
    box-shadow: 2px 0 8px rgba(0,0,0,0.15);
    z-index: 999;
  }
  .sidebar .logo {
    color: #4c6ef5;
    font-size: 28px;
    font-weight: 900;
    text-align: center;
    margin-bottom: 35px;
    letter-spacing: 1.6px;
    user-select: none;
  }
  .sidebar nav a {
    display: flex;
    align-items: center;
    padding: 15px 28px;
    color: #a0a0b8;
    font-weight: 600;
    text-decoration: none;
    border-radius: 8px;
    margin: 6px 14px;
    transition: all 0.3s ease;
  }
  .sidebar nav a i {
    margin-right: 16px;
    font-size: 20px;
    width: 22px;
    text-align: center;
  }
  .sidebar nav a:hover, .sidebar nav a.active {
    background: #4c6ef5;
    color: white;
    box-shadow: 0 4px 12px rgba(76,110,245,0.6);
  }
  .sidebar footer {
    margin-top: auto;
    padding: 18px 0;
    font-size: 14px;
    color: #666;
    text-align: center;
  }

  /* Main content */
  .main-content {
    margin-left: 250px;
    padding: 30px 48px 48px;
    min-height: 100vh;
    background: #fff;
  }
  h1 {
    color: #4c6ef5;
    font-weight: 900;
    font-size: 2.2rem;
    margin-bottom: 30px;
  }

  /* Calendar table */
  table.calendar {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 10px;
    box-shadow: 0 4px 15px rgb(0 0 0 / 0.05);
  }
  table.calendar thead th {
    color: #4c6ef5;
    font-weight: 700;
    font-size: 1rem;
    text-align: center;
    padding: 14px 0;
    background: #e7eafd;
    border-radius: 12px;
    user-select: none;
  }
  table.calendar tbody td {
    background: #fafbfe;
    text-align: center;
    vertical-align: top;
    padding: 14px 8px;
    border-radius: 12px;
    position: relative;
    cursor: default;
    transition: background-color 0.3s ease;
    font-weight: 600;
    font-size: 1.05rem;
    color: #222;
  }
  table.calendar tbody td.empty {
    background: transparent;
    cursor: default;
    box-shadow: none;
  }
  table.calendar tbody td.today {
    background: #4c6ef5;
    color: white;
    font-weight: 800;
  }
  table.calendar tbody td.event-day {
    cursor: pointer;
    box-shadow: 0 0 12px #4c6ef5aa;
  }
  table.calendar tbody td.event-day:hover {
    background: #dbeafe;
  }

  /* Tooltip for events */
  .tooltip {
    position: absolute;
    top: 42px;
    left: 50%;
    transform: translateX(-50%);
    background: #4c6ef5;
    color: white;
    padding: 8px 14px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    max-width: 220px;
    white-space: pre-line;
    box-shadow: 0 8px 20px rgb(76 110 245 / 0.4);
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.2s ease;
    z-index: 1000;
  }
  .tooltip::after {
    content: '';
    position: absolute;
    bottom: 100%;
    left: 50%;
    margin-left: -6px;
    border-width: 6px;
    border-style: solid;
    border-color: transparent transparent #4c6ef5 transparent;
  }
  .tooltip.show {
    opacity: 1;
    pointer-events: auto;
  }

  /* Responsive */
  @media (max-width: 768px) {
    .sidebar {
      width: 70px;
      padding-top: 14px;
    }
    .sidebar .logo {
      font-size: 20px;
      margin-bottom: 20px;
      letter-spacing: normal;
    }
    .sidebar nav a span {
      display: none;
    }
    .sidebar nav a {
      justify-content: center;
      padding: 14px 0;
      margin: 6px 0;
    }
    .main-content {
      margin-left: 70px;
      padding: 30px 20px 40px;
    }
    table.calendar thead th, table.calendar tbody td {
      font-size: 0.85rem;
    }
  }
</style>
</head>
<body>

<div class="sidebar">
  <div class="logo">Funeral Aid</div>
  <nav>
    <a href="dashboard.php"><i class="fa-solid fa-house"></i> <span>Home</span></a>
    <a href="calendar.php" class="active"><i class="fa-regular fa-calendar-days"></i> <span>Calendar</span></a>
    <a href="add_event.php"><i class="fa-solid fa-plus"></i> <span>Add Event</span></a>
    <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> <span>Logout</span></a>
  </nav>
  <footer>&copy; <?= date('Y') ?> LAHIRU R. PERERA</footer>
</div>

<div class="main-content">
  <h1>Calendar - <?= date('F Y') ?></h1>
  <table class="calendar" role="grid" aria-label="Calendar for <?= date('F Y') ?>">
    <thead>
      <tr>
        <th scope="col">Mon</th><th scope="col">Tue</th><th scope="col">Wed</th><th scope="col">Thu</th><th scope="col">Fri</th><th scope="col">Sat</th><th scope="col">Sun</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($calendar as $week): ?>
        <tr>
          <?php foreach ($week as $day): ?>
            <?php if ($day === null): ?>
              <td class="empty" aria-disabled="true"></td>
            <?php else: 
              $isToday = ($day['day'] == date('j') && $month == date('m') && $year == date('Y'));
              $hasEvents = !empty($day['events']);
              $dayId = "day-" . $day['day'];
            ?>
              <td tabindex="0" id="<?= $dayId ?>" class="<?= $isToday ? 'today' : '' ?> <?= $hasEvents ? 'event-day' : '' ?>" aria-label="Day <?= $day['day'] ?><?= $hasEvents ? ', Has events' : '' ?>">
                <?= $day['day'] ?>
                <?php if ($hasEvents): ?>
                  <div class="tooltip" role="tooltip" aria-hidden="true" id="<?= $dayId ?>-tooltip">
                    <?= implode("<br>", array_map('htmlspecialchars', $day['events'])) ?>
                  </div>
                <?php endif; ?>
              </td>
            <?php endif; ?>
          <?php endforeach; ?>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<script>
  // Show tooltip on focus/hover for accessible events
  document.querySelectorAll('td.event-day').forEach(cell => {
    const tooltip = cell.querySelector('.tooltip');
    if (!tooltip) return;

    function showTooltip() {
      tooltip.classList.add('show');
      tooltip.setAttribute('aria-hidden', 'false');
    }
    function hideTooltip() {
      tooltip.classList.remove('show');
      tooltip.setAttribute('aria-hidden', 'true');
    }

    cell.addEventListener('mouseenter', showTooltip);
    cell.addEventListener('mouseleave', hideTooltip);
    cell.addEventListener('focus', showTooltip);
    cell.addEventListener('blur', hideTooltip);
  });
</script>

</body>
</html>
