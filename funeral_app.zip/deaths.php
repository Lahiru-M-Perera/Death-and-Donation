<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Fetch all death records ordered by date
$deaths = $conn->query("SELECT id, person_name, date_of_death FROM death ORDER BY date_of_death DESC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch donated goods and total aid if death_id specified
$donations = [];
$aidTotal = 0;
if (!empty($_GET['death_id'])) {
    $death_id = intval($_GET['death_id']);

    // Donations grouped by item
    $stmt = $conn->prepare("
        SELECT i.item_name, SUM(dn.donation_qty) AS total_qty
        FROM donations dn
        JOIN inventory i ON dn.item_id = i.id
        WHERE dn.death_id = ?
        GROUP BY i.id, i.item_name
        ORDER BY i.item_name
    ");
    $stmt->execute([$death_id]);
    $donations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Sum total aid amount for this death record
    $aidStmt = $conn->prepare("
        SELECT COALESCE(SUM(total_amount), 0) AS total_aid
        FROM aids
        WHERE death_id = ?
    ");
    $aidStmt->execute([$death_id]);
    $aidTotal = $aidStmt->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Death Records & Donations</title>
<style>
    body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 20px; }
    .container { max-width: 900px; margin: auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);}
    h2 { text-align: center; color: #cc0000; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
    th, td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
    th { background-color: #cc0000; color: white; }
    a { color: #cc0000; text-decoration: none; }
    a:hover { text-decoration: underline; }
    .no-data { font-style: italic; color: #666; }
    .summary { margin-bottom: 20px; font-weight: bold; }
</style>
</head>
<body>
<div class="container">
    <h2>Death Records</h2>
    <table>
        <thead>
            <tr>
                <th>Person Name</th>
                <th>Date of Death</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php if (count($deaths) === 0): ?>
            <tr><td colspan="3" class="no-data">No death records found.</td></tr>
        <?php else: ?>
            <?php foreach ($deaths as $death): ?>
                <tr>
                    <td><?= htmlspecialchars($death['person_name']) ?></td>
                    <td><?= htmlspecialchars($death['date_of_death']) ?></td>
                    <td><a href="?death_id=<?= $death['id'] ?>">View Donations & Aid</a></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

    <?php if (!empty($donations) || isset($death_id)): ?>
        <div class="summary">
            <p>Total Aid Amount: <?= number_format($aidTotal, 2) ?> LKR</p>
        </div>

        <?php if (!empty($donations)): ?>
            <h3>Donated Goods</h3>
            <table>
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Quantity Donated</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($donations as $donation): ?>
                        <tr>
                            <td><?= htmlspecialchars($donation['item_name']) ?></td>
                            <td><?= intval($donation['total_qty']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-data">No donations recorded for this person.</p>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>
