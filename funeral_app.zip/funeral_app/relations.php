<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$error = "";
$success = "";

// Get last registered relation reg_no (if any)
$lastRegNo = "";
try {
    $stmt = $conn->query("SELECT reg_no FROM relations ORDER BY id DESC LIMIT 1");
    $lastRegNo = $stmt->fetchColumn() ?: "No relations yet";
} catch (PDOException $e) {
    $lastRegNo = "Error fetching last reg no";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $reg_no = trim($_POST['reg_no']);
    $full_name = trim($_POST['full_name']);
    $address = trim($_POST['address']);
    $dob = $_POST['dob'];
    $nic = trim($_POST['nic']);
    $phone = trim($_POST['phone']);
    $relation_type = trim($_POST['relation_type']);
    $gender = trim($_POST['gender']);  // Added gender

    // Basic validation
    if (!$reg_no || !$full_name || !$relation_type || !$gender) {
        $error = "Please fill in all required fields (Registration Number, Full Name, Relation Type, Gender).";
    }

    if (!$error) {
        $sql = "INSERT INTO relations (reg_no, full_name, address, dob, nic, phone, relation_type, gender) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        try {
            $stmt->execute([$reg_no, $full_name, $address, $dob, $nic, $phone, $relation_type, $gender]);
            $success = "Relation added successfully!";
            $lastRegNo = $reg_no;
        } catch (PDOException $ex) {
            $error = "Database error: " . $ex->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Add Relation</title>
<style>
    /* Reset */
    * {
        box-sizing: border-box;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f8f9fb;
        margin: 0;
        padding: 0;
        color: #333;
    }

    /* Header / Navbar */
    header {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: #2c7be5;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 30px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.15);
        z-index: 1000;
    }

    header .nav-links a {
        color: #cfe2ff;
        text-decoration: none;
        margin-left: 20px;
        font-weight: 600;
        font-size: 1rem;
        transition: color 0.3s ease;
    }

    header .nav-links a:hover {
        color: #a2c4f7;
    }

    header .last-reg {
        font-size: 0.95rem;
        font-weight: 600;
    }

    /* Main container */
    .container {
        max-width: 700px;
        background: #fff;
        margin: 90px auto 40px;
        padding: 30px 40px;
        border-radius: 10px;
        box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }

    h2 {
        text-align: center;
        margin-bottom: 25px;
        font-weight: 700;
        color: #2c7be5;
        letter-spacing: 1px;
    }

    label {
        display: block;
        margin-top: 18px;
        font-weight: 600;
        color: #555;
    }

    input[type="text"],
    input[type="date"],
    input[type="tel"],
    select,
    textarea {
        width: 100%;
        padding: 10px 14px;
        margin-top: 6px;
        border-radius: 6px;
        border: 1.8px solid #ccc;
        font-size: 1rem;
        font-family: inherit;
        transition: border-color 0.3s ease;
    }

    input[type="text"]:focus,
    input[type="date"]:focus,
    input[type="tel"]:focus,
    select:focus,
    textarea:focus {
        border-color: #2c7be5;
        outline: none;
        box-shadow: 0 0 6px rgba(44,123,229,0.4);
    }

    textarea {
        resize: vertical;
        min-height: 70px;
    }

    button {
        margin-top: 30px;
        width: 100%;
        padding: 14px 0;
        background-color: #2c7be5;
        color: white;
        font-size: 18px;
        font-weight: 700;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    button:hover {
        background-color: #1a5fd3;
    }

    /* Alert boxes */
    .error, .success {
        margin-bottom: 20px;
        padding: 12px 18px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 1rem;
        text-align: center;
        user-select: none;
    }

    .error {
        background-color: #ffe5e5;
        color: #cc0000;
        border: 1px solid #cc0000;
    }

    .success {
        background-color: #d6f5d6;
        color: #2d662d;
        border: 1px solid #2d662d;
    }

    /* Responsive */
    @media(max-width: 480px) {
        .container {
            margin: 100px 15px 40px;
            padding: 20px 25px;
        }
        header {
            flex-direction: column;
            align-items: flex-start;
            padding: 12px 15px;
        }
        header .nav-links {
            margin-top: 8px;
        }
        header .nav-links a {
            margin-left: 0;
            margin-right: 15px;
        }
    }
</style>
</head>
<body>
<header>
    <div class="last-reg">Last Registered Relation No: <?= htmlspecialchars($lastRegNo) ?></div>
    <nav class="nav-links">
        <a href="dashboard.php" title="Go to Dashboard">Dashboard</a>
        <a href="members.php" title="Go to Members">Members</a>
    </nav>
</header>

<div class="container">
    <h2>Add New Relation</h2>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
        <label for="reg_no">Registration Number</label>
        <input type="text" name="reg_no" id="reg_no" required placeholder="Member's Registration Number" />

        <label for="full_name">Full Name</label>
        <input type="text" name="full_name" id="full_name" required placeholder="Relation's Full Name" />

        <label for="address">Address</label>
        <textarea name="address" id="address" rows="3" placeholder="Relation's Address"></textarea>

        <label for="dob">Date of Birth</label>
        <input type="date" name="dob" id="dob" />

        <label for="nic">NIC</label>
        <input type="text" name="nic" id="nic" maxlength="12" placeholder="National ID Number" />

        <label for="phone">Phone Number</label>
        <input type="tel" name="phone" id="phone" pattern="[0-9]{10}" placeholder="10 digit number" />

        <label for="gender">Gender</label>
        <select name="gender" id="gender" required>
            <option value="" disabled selected>Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select>

        <label for="relation_type">Relation Type</label>
        <select name="relation_type" id="relation_type" required>
            <option value="" disabled selected>Select relation type</option>
            <option value="Father">Father</option>
            <option value="Mother">Mother</option>
            <option value="Brother">Brother</option>
            <option value="Sister">Sister</option>
            <option value="Spouse">Spouse</option>
            <option value="Child">Child</option>
        </select>

        <button type="submit">Add Relation</button>
    </form>
</div>
</body>
</html>
