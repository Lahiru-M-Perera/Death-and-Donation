<?php
require "config.php";

if (isLoggedIn()) {
    header("Location: dashboard.php");
    exit();
}

$error = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? "");
    $password = trim($_POST['password'] ?? "");

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Plain text password check (no hashing)
    if ($user && $password === $user['password']) {
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['name'] = $user['name'];

        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Invalid Username or Password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Login - Funeral Aid System</title>
<style>
    /* Reset and base */
    * {
        box-sizing: border-box;
        margin: 0; padding: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    body {
        background: linear-gradient(135deg, #667eea, #764ba2);
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #333;
    }
    .login-container {
        background: #fff;
        padding: 40px 50px;
        border-radius: 12px;
        box-shadow: 0 12px 30px rgba(0,0,0,0.2);
        width: 380px;
        text-align: center;
        animation: fadeIn 1s ease forwards;
    }
    @keyframes fadeIn {
        from {opacity: 0; transform: translateY(30px);}
        to {opacity: 1; transform: translateY(0);}
    }
    h2 {
        margin-bottom: 30px;
        font-weight: 700;
        color: #444;
    }
    form {
        text-align: left;
    }
    label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #555;
    }
    input[type="text"], input[type="password"] {
        width: 100%;
        padding: 12px 15px;
        margin-bottom: 20px;
        border: 1.5px solid #ddd;
        border-radius: 8px;
        font-size: 16px;
        transition: border-color 0.3s ease;
    }
    input[type="text"]:focus, input[type="password"]:focus {
        border-color: #667eea;
        outline: none;
        box-shadow: 0 0 6px rgba(102, 126, 234, 0.6);
    }
    button {
        width: 100%;
        padding: 14px 0;
        background-color: #667eea;
        border: none;
        border-radius: 10px;
        color: white;
        font-size: 18px;
        font-weight: 700;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    button:hover {
        background-color: #5a67d8;
    }
    .error {
        background: #f8d7da;
        color: #842029;
        border: 1px solid #f5c2c7;
        padding: 14px;
        margin-bottom: 20px;
        border-radius: 8px;
        font-weight: 600;
        text-align: center;
    }
    @media (max-width: 420px) {
        .login-container {
            width: 90%;
            padding: 30px 20px;
        }
    }
</style>
</head>
<body>
<div class="login-container">
    <h2>Login</h2>
    <?php if ($error): ?>
        <div class="error"><?=htmlspecialchars($error)?></div>
    <?php endif; ?>
    <form method="post" action="">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" required autocomplete="off" />

        <label for="password">Password</label>
        <input type="password" id="password" name="password" required autocomplete="off" />

        <button type="submit">Login</button>
    </form>
</div>
</body>
</html>

