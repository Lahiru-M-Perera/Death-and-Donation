<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Get member reg_no from GET
if (!isset($_GET['reg_no'])) {
    die("No member registration number specified.");
}
$reg_no = $_GET['reg_no'];

// Initialize messages
$error = "";
$success = "";

// Handle Member update submission
if (isset($_POST['update_member'])) {
    $full_name = trim($_POST['full_name']);
    $address = trim($_POST['address']);
    $dob = $_POST['dob'];
    $nic = trim($_POST['nic']);
    $joined_date = $_POST['joined_date'];
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $status = trim($_POST['status']);
    $gender = trim($_POST['gender']);  // NEW

    // For simplicity, skipping photo update here - you can add similar logic if needed

    $sql = "UPDATE members SET full_name=?, address=?, dob=?, nic=?, joined_date=?, phone=?, email=?, status=?, gender=? WHERE reg_no=?";
    $stmt = $conn->prepare($sql);
    try {
        $stmt->execute([$full_name, $address, $dob, $nic, $joined_date, $phone, $email, $status, $gender, $reg_no]);
        $success = "Member details updated successfully.";
    } catch (PDOException $ex) {
        $error = "Member update failed: " . $ex->getMessage();
    }
}

// Handle Relation update submission
if (isset($_POST['update_relation'])) {
    $relation_id = (int)$_POST['relation_id'];
    $full_name_r = trim($_POST['relation_full_name']);
    $address_r = trim($_POST['relation_address']);
    $dob_r = $_POST['relation_dob'];
    $nic_r = trim($_POST['relation_nic']);
    $phone_r = trim($_POST['relation_phone']);
    $relation_type = trim($_POST['relation_type']);
    $gender_r = trim($_POST['relation_gender']);  // NEW

    $sql = "UPDATE relations SET full_name=?, address=?, dob=?, nic=?, phone=?, relation_type=?, gender=? WHERE id=? AND reg_no=?";
    $stmt = $conn->prepare($sql);
    try {
        $stmt->execute([$full_name_r, $address_r, $dob_r, $nic_r, $phone_r, $relation_type, $gender_r, $relation_id, $reg_no]);
        $success = "Relation updated successfully.";
    } catch (PDOException $ex) {
        $error = "Relation update failed: " . $ex->getMessage();
    }
}

// Handle adding new relation
if (isset($_POST['add_relation'])) {
    $full_name_r = trim($_POST['new_relation_full_name']);
    $address_r = trim($_POST['new_relation_address']);
    $dob_r = $_POST['new_relation_dob'];
    $nic_r = trim($_POST['new_relation_nic']);
    $phone_r = trim($_POST['new_relation_phone']);
    $relation_type = trim($_POST['new_relation_type']);
    $gender_r = trim($_POST['new_relation_gender']);  // NEW

    $sql = "INSERT INTO relations (reg_no, full_name, address, dob, nic, phone, relation_type, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    try {
        $stmt->execute([$reg_no, $full_name_r, $address_r, $dob_r, $nic_r, $phone_r, $relation_type, $gender_r]);
        $success = "New relation added successfully.";
    } catch (PDOException $ex) {
        $error = "Failed to add relation: " . $ex->getMessage();
    }
}

// Fetch member data
$stmt = $conn->prepare("SELECT * FROM members WHERE reg_no = ?");
$stmt->execute([$reg_no]);
$member = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$member) {
    die("Member not found.");
}

// Fetch relations of this member
$stmt = $conn->prepare("SELECT * FROM relations WHERE reg_no = ? ORDER BY id DESC");
$stmt->execute([$reg_no]);
$relations = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Update Member & Relations</title>
<style>
    body { font-family: Arial, sans-serif; background:#f5f6fa; padding:20px; }
    h1, h2 { color: #2c7be5; }
    form { background:#fff; padding:20px; border-radius:8px; box-shadow:0 2px 6px rgba(0,0,0,0.1); margin-bottom:40px; }
    label { display:block; margin-top:12px; font-weight:600; }
    input, select, textarea { width:100%; padding:8px; margin-top:6px; border:1px solid #ccc; border-radius:5px; font-size:1rem; }
    button { margin-top:20px; background:#2c7be5; color:#fff; padding:12px 20px; border:none; border-radius:6px; font-weight:700; cursor:pointer; }
    button:hover { background:#1a5fd3; }
    .error { background:#ffe5e5; color:#cc0000; padding:10px; border-radius:6px; margin-bottom:20px; }
    .success { background:#d6f5d6; color:#2d662d; padding:10px; border-radius:6px; margin-bottom:20px; }
    .relation-block { border:1px solid #ccc; padding:15px; margin-bottom:15px; border-radius:8px; background:#fafafa; }
</style>
</head>
<body>

<h1>Update Member: <?= htmlspecialchars($member['full_name']) ?> (<?= htmlspecialchars($member['reg_no']) ?>)</h1>

<?php if($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php elseif($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<!-- Member Update Form -->
<form method="POST" novalidate>
    <input type="hidden" name="update_member" value="1" />
    <label>Full Name</label>
    <input type="text" name="full_name" value="<?= htmlspecialchars($member['full_name']) ?>" required />

    <label>Address</label>
    <textarea name="address" rows="3" required><?= htmlspecialchars($member['address']) ?></textarea>

    <label>Date of Birth</label>
    <input type="date" name="dob" value="<?= htmlspecialchars($member['dob']) ?>" required />

    <label>NIC</label>
    <input type="text" name="nic" value="<?= htmlspecialchars($member['nic']) ?>" maxlength="12" />

    <label>Joined Date</label>
    <input type="date" name="joined_date" value="<?= htmlspecialchars($member['joined_date']) ?>" required />

    <label>Phone</label>
    <input type="tel" name="phone" value="<?= htmlspecialchars($member['phone']) ?>" pattern="[0-9]{10}" required />

    <label>Gender</label>
    <select name="gender" required>
        <option value="" disabled <?= empty($member['gender']) ? 'selected' : '' ?>>Select Gender</option>
        <option value="Male" <?= ($member['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
        <option value="Female" <?= ($member['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
        <option value="Other" <?= ($member['gender'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>
    </select>

    <label>Email</label>
    <input type="email" name="email" value="<?= htmlspecialchars($member['email']) ?>" required />

    <label>Status</label>
    <select name="status" required>
        <option value="active" <?= $member['status']=='active'?'selected':'' ?>>Active</option>
        <option value="inactive" <?= $member['status']=='inactive'?'selected':'' ?>>Inactive</option>
        <option value="deceased" <?= $member['status']=='deceased'?'selected':'' ?>>Deceased</option>
    </select>

    <button type="submit">Update Member</button>
</form>

<hr>

<h2>Relations</h2>

<?php foreach ($relations as $rel): ?>
    <form method="POST" novalidate class="relation-block">
        <input type="hidden" name="update_relation" value="1" />
        <input type="hidden" name="relation_id" value="<?= $rel['id'] ?>" />

        <label>Relation Full Name</label>
        <input type="text" name="relation_full_name" value="<?= htmlspecialchars($rel['full_name']) ?>" required />

        <label>Address</label>
        <textarea name="relation_address" rows="2" required><?= htmlspecialchars($rel['address']) ?></textarea>

        <label>Date of Birth</label>
        <input type="date" name="relation_dob" value="<?= htmlspecialchars($rel['dob']) ?>" required />

        <label>NIC</label>
        <input type="text" name="relation_nic" value="<?= htmlspecialchars($rel['nic']) ?>" maxlength="12" />

        <label>Phone</label>
        <input type="tel" name="relation_phone" value="<?= htmlspecialchars($rel['phone']) ?>" pattern="[0-9]{10}" required />

        <label>Gender</label>
        <select name="relation_gender" required>
            <option value="" disabled <?= empty($rel['gender']) ? 'selected' : '' ?>>Select Gender</option>
            <option value="Male" <?= ($rel['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
            <option value="Female" <?= ($rel['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
            <option value="Other" <?= ($rel['gender'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>
        </select>

        <label>Relation Type</label>
        <select name="relation_type" required>
            <option value="Father" <?= $rel['relation_type']=='Father'?'selected':'' ?>>Father</option>
            <option value="Mother" <?= $rel['relation_type']=='Mother'?'selected':'' ?>>Mother</option>
            <option value="Spouse" <?= $rel['relation_type']=='Spouse'?'selected':'' ?>>Spouse</option>
            <option value="Child" <?= $rel['relation_type']=='Child'?'selected':'' ?>>Child</option>
            <option value="Other" <?= $rel['relation_type']=='Other'?'selected':'' ?>>Other</option>
        </select>

        <button type="submit">Update Relation</button>
    </form>
<?php endforeach; ?>

<hr>

<h2>Add New Relation</h2>
<form method="POST" novalidate>
    <input type="hidden" name="add_relation" value="1" />

    <label>Relation Full Name</label>
    <input type="text" name="new_relation_full_name" required />

    <label>Address</label>
    <textarea name="new_relation_address" rows="2" required></textarea>

    <label>Date of Birth</label>
    <input type="date" name="new_relation_dob" required />

    <label>NIC</label>
    <input type="text" name="new_relation_nic" maxlength="12" />

    <label>Phone</label>
    <input type="tel" name="new_relation_phone" pattern="[0-9]{10}" required />

    <label>Gender</label>
    <select name="new_relation_gender" required>
        <option value="" disabled selected>Select Gender</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
        <option value="Other">Other</option>
    </select>

    <label>Relation Type</label>
    <select name="new_relation_type" required>
        <option value="" disabled selected>Select relation type</option>
        <option value="Father">Father</option>
        <option value="Mother">Mother</option>
        <option value="Spouse">Spouse</option>
        <option value="Child">Child</option>
        <option value="Other">Other</option>
    </select>

    <button type="submit">Add Relation</button>
</form>

</body>
</html>
