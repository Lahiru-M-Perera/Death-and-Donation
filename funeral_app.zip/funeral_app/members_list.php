<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch members with their relations count
    $sql = "SELECT m.reg_no, m.full_name, COUNT(r.id) AS relations_count
            FROM members m
            LEFT JOIN relations r ON r.reg_no = m.reg_no
            GROUP BY m.reg_no, m.full_name
            ORDER BY m.full_name ASC";
    $stmt = $conn->query($sql);
    $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("DB Connection or query failed: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Members List</title>
<style>
  /* Reset some default styles */
  * {
    box-sizing: border-box;
  }

  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f9faff;
    margin: 0;
    padding: 40px 20px;
    color: #333;
  }

  h1 {
    text-align: center;
    color: #2c3e50;
    margin-bottom: 30px;
    font-weight: 700;
    letter-spacing: 1.2px;
  }

  .container {
    max-width: 600px;
    margin: 0 auto;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 18px rgba(0,0,0,0.1);
    padding: 20px 30px;
  }

  ul.members-list {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  ul.members-list li {
    padding: 15px 20px;
    margin-bottom: 10px;
    background: #ecf0f1;
    border-radius: 8px;
    transition: background-color 0.3s ease;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  ul.members-list li:hover {
    background: #3498db;
  }

  ul.members-list li a {
    text-decoration: none;
    color: #2c3e50;
    font-size: 1.1rem;
    font-weight: 600;
    transition: color 0.3s ease;
    flex-grow: 1;
  }

  ul.members-list li:hover a {
    color: #fff;
  }

  .reg-no {
    font-weight: 400;
    font-size: 0.9rem;
    color: #7f8c8d;
    margin-left: 8px;
  }

  .relations-count {
    background: #2c7be5;
    color: white;
    font-weight: 700;
    padding: 5px 12px;
    border-radius: 12px;
    font-size: 0.9rem;
    min-width: 38px;
    text-align: center;
  }

  @media (max-width: 480px) {
    body {
      padding: 20px 10px;
    }
    .container {
      padding: 15px 20px;
    }
    ul.members-list li {
      padding: 12px 15px;
      font-size: 1rem;
      flex-direction: column;
      align-items: flex-start;
      gap: 6px;
    }
    .relations-count {
      min-width: auto;
      padding: 3px 10px;
      font-size: 0.85rem;
    }
  }
</style>
</head>
<body>
<div class="container">
  <h1>Members List</h1>
  <?php if (!empty($members)): ?>
  <ul class="members-list">
    <?php foreach ($members as $member): ?>
      <li>
        <a href="update_member_relations.php?reg_no=<?= urlencode($member['reg_no']) ?>">
          <?= htmlspecialchars($member['full_name']) ?>
          <span class="reg-no">(<?= htmlspecialchars($member['reg_no']) ?>)</span>
        </a>
        <div class="relations-count" title="Number of relations">
          <?= $member['relations_count'] ?>
        </div>
      </li>
    <?php endforeach; ?>
  </ul>
  <?php else: ?>
    <p>No members found.</p>
  <?php endif; ?>
</div>
</body>
</html>
