<?php
session_start();

// DB Connection
$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Fetch all deaths with donation summaries
$sql = "SELECT d.id, d.reg_no, d.person_name, d.date_of_death,
               IFNULL(SUM(o.amount), 0) AS total_donations,
               COUNT(o.id) AS donation_count
        FROM death d
        LEFT JOIN donations o ON d.id = o.death_id
        GROUP BY d.id
        ORDER BY d.date_of_death DESC";
$deaths = $conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);

// If a specific death is selected, fetch its donation details
$donations = [];
if (!empty($_GET['death_id'])) {
    $death_id = $_GET['death_id'];

    $donStmt = $conn->prepare("SELECT donor_name, amount, donation_date, note
                               FROM donations
                               WHERE death_id = ?
                               ORDER BY donation_date DESC");
    $donStmt->execute([$death_id]);
    $donations = $donStmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Death & Donations</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f8; }
        .container { width: 90%; margin: auto; padding: 20px; background: #fff; border-radius: 8px; margin-top: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
        th { background: #007BFF; color: white; }
        a { text-decoration: none; color: #007BFF; }
        a:hover { text-decoration: underline; }
        .total { font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h2>Death Records & Donations</h2>

    <table>
        <tr>
            <th>Reg No</th>
            <th>Person Name</th>
            <th>Date of Death</th>
            <th>Total Donations</th>
            <th>Donation Count</th>
            <th>Action</th>
        </tr>
        <?php foreach ($deaths as $row): ?>
        <tr>
            <td><?= htmlspecialchars($row['reg_no']) ?></td>
            <td><?= htmlspecialchars($row['person_name']) ?></td>
            <td><?= htmlspecialchars($row['date_of_death']) ?></td>
            <td class="total"><?= number_format($row['total_donations'], 2) ?></td>
            <td><?= $row['donation_count'] ?></td>
            <td><a href="?death_id=<?= $row['id'] ?>">View Donations</a></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <?php if (!empty($donations)): ?>
        <h3>Donations for Selected Person</h3>
        <table>
            <tr>
                <th>Donor Name</th>
                <th>Amount</th>
                <th>Donation Date</th>
                <th>Note</th>
            </tr>
            <?php foreach ($donations as $don): ?>
            <tr>
                <td><?= htmlspecialchars($don['donor_name']) ?></td>
                <td><?= number_format($don['amount'], 2) ?></td>
                <td><?= htmlspecialchars($don['donation_date']) ?></td>
                <td><?= htmlspecialchars($don['note']) ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</div>
</body>
</html>
