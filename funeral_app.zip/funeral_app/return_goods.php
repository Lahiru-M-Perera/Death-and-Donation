<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$error = "";
$success = "";

// Process return form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donation_id = $_POST['donation_id'] ?? null;
    $return_qty = intval($_POST['return_qty'] ?? 0);

    if (!$donation_id || $return_qty <= 0) {
        $error = "Please select a valid record and enter a positive return quantity.";
    } else {
        try {
            $conn->beginTransaction();

            // Get current donation details
            $stmt = $conn->prepare("SELECT donation_qty, returned_qty, item_id FROM donations WHERE id = ?");
            $stmt->execute([$donation_id]);
            $donation = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$donation) {
                throw new Exception("Donation record not found.");
            }

            $pending_qty = $donation['donation_qty'] - $donation['returned_qty'];
            if ($return_qty > $pending_qty) {
                throw new Exception("Return quantity cannot exceed pending quantity ($pending_qty).");
            }

            // Update returned_qty in donations table
            $stmt = $conn->prepare("UPDATE donations SET returned_qty = returned_qty + ? WHERE id = ?");
            $stmt->execute([$return_qty, $donation_id]);

            // Update current_qty in inventory table
            $stmt = $conn->prepare("UPDATE inventory SET current_qty = current_qty + ? WHERE id = ?");
            $stmt->execute([$return_qty, $donation['item_id']]);

            $conn->commit();
            $success = "Return processed successfully.";
        } catch (Exception $ex) {
            $conn->rollBack();
            $error = "Failed to process return: " . $ex->getMessage();
        }
    }
}

// Fetch borrowed items with pending returns
$sql = "
SELECT 
    d.id AS donation_id,
    m.full_name,
    m.reg_no,
    i.item_name,
    d.donation_qty,
    d.returned_qty,
    (d.donation_qty - d.returned_qty) AS pending_qty,
    d.donation_date
FROM donations d
JOIN members m ON d.member_id = m.id
JOIN inventory i ON d.item_id = i.id
WHERE d.donation_qty > d.returned_qty
ORDER BY d.donation_date DESC
";

$borrowedItems = $conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Goods Return Management</title>
<style>
body {
    font-family: Arial, sans-serif;
    max-width: 900px;
    margin: 20px auto;
    background: #f9fafb;
    padding: 20px;
}
h1 {
    color: #2c7be5;
    text-align: center;
    margin-bottom: 25px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 25px;
}
th, td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: center;
}
th {
    background-color: #2c7be5;
    color: white;
}
input[type="number"] {
    width: 80px;
    padding: 6px;
    border-radius: 6px;
    border: 1.5px solid #ccc;
    font-size: 1rem;
}
button {
    padding: 10px 20px;
    background-color: #2c7be5;
    border: none;
    color: white;
    border-radius: 6px;
    cursor: pointer;
}
button:hover {
    background-color: #1a5fd3;
}
.error {
    background: #ffe5e5;
    color: #cc0000;
    padding: 12px;
    border-radius: 8px;
    font-weight: 600;
    margin-bottom: 20px;
    text-align: center;
}
.success {
    background: #d6f5d6;
    color: #2d662d;
    padding: 12px;
    border-radius: 8px;
    font-weight: 600;
    margin-bottom: 20px;
    text-align: center;
}
form {
    margin: 0;
}
</style>
</head>
<body>

<h1>Goods Return Management</h1>

<?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<?php if (count($borrowedItems) === 0): ?>
    <p>No borrowed goods pending return.</p>
<?php else: ?>
<table>
    <thead>
        <tr>
            <th>Member Name</th>
            <th>Reg No</th>
            <th>Item Name</th>
            <th>Qty Borrowed</th>
            <th>Qty Returned</th>
            <th>Pending Qty</th>
            <th>Donation Date</th>
            <th>Return Qty</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($borrowedItems as $item): ?>
        <tr>
            <td><?= htmlspecialchars($item['full_name']) ?></td>
            <td><?= htmlspecialchars($item['reg_no']) ?></td>
            <td><?= htmlspecialchars($item['item_name']) ?></td>
            <td><?= intval($item['donation_qty']) ?></td>
            <td><?= intval($item['returned_qty']) ?></td>
            <td><?= intval($item['pending_qty']) ?></td>
            <td><?= htmlspecialchars($item['donation_date']) ?></td>
            <td>
                <form method="POST" style="margin:0;">
                    <input type="hidden" name="donation_id" value="<?= $item['donation_id'] ?>" />
                    <input type="number" name="return_qty" min="1" max="<?= $item['pending_qty'] ?>" required />
            </td>
            <td>
                    <button type="submit">Return</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>

</body>
</html>
