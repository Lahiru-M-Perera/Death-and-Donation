<?php
session_start();

$host = "localhost";
$db = "funeral_db";
$user = "root";
$pass = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Simple function to check login
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Role check
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Redirect if not logged in
function checkLogin() {
    if (!isLoggedIn()) {
        header("Location: index.php");
        exit();
    }
}
?>
