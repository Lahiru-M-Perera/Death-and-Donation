<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$error = "";
$success = "";

// Fetch members for dropdown (include member id so we can request relations)
$members = $conn->query("SELECT id, reg_no, full_name FROM members ORDER BY full_name")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reg_no = $_POST['reg_no'] ?? '';
    $person_name = trim($_POST['person_name'] ?? '');
    $date_of_death = $_POST['date_of_death'] ?? '';
    $cause_of_death = trim($_POST['cause_of_death'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    if (empty($person_name) || empty($date_of_death)) {
        $error = "Please fill in required fields (Name and Date of Death).";
    } else {
        try {
            $stmt = $conn->prepare("
                INSERT INTO death (reg_no, person_name, date_of_death, cause_of_death, notes, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$reg_no, $person_name, $date_of_death, $cause_of_death, $notes]);
            $success = "Death record added successfully.";
            // Optionally clear fields (server-side)
            $reg_no = $person_name = $date_of_death = $cause_of_death = $notes = '';
        } catch (Exception $ex) {
            $error = "Error adding death record: " . $ex->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Death Record</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f9fafb;
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
}
h1 { text-align: center; color: #cc0000; }
form {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
label { margin-top: 10px; display: block; font-weight:600; }
input, select, textarea {
    width: 100%;
    padding: 8px;
    margin-top: 6px;
    border: 1px solid #ccc;
    border-radius: 6px;
    box-sizing: border-box;
}
.button-row { display:flex; gap:10px; margin-top:15px; }
button {
    background: #cc0000;
    color: white;
    padding: 10px 14px;
    border: none;
    border-radius: 6px;
    font-size: 1rem;
    cursor: pointer;
}
button:hover { background: #a80000; }
.error, .success {
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 6px;
    font-weight: bold;
}
.error { background: #ffe5e5; color: #cc0000; }
.success { background: #d6f5d6; color: #2d662d; }
/* responsive */
@media(max-width:600px){ .button-row { flex-direction:column; } }
</style>
</head>
<body>

<h1>Add Death Record</h1>

<?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST" id="deathForm" autocomplete="off">
    <label for="reg_no">Select Member (Optional)</label>
    <select name="reg_no" id="reg_no">
        <option value="">-- Not a member --</option>
        <?php foreach ($members as $m): ?>
            <option value="<?= htmlspecialchars($m['reg_no']) ?>" data-member-id="<?= (int)$m['id'] ?>">
                <?= htmlspecialchars($m['full_name'] . " (" . $m['reg_no'] . ")") ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="relation_select">Select Relation or Member</label>
    <select id="relation_select">
        <option value="">-- No relation / choose member --</option>
    </select>

    <label for="person_name">Full Name *</label>
    <input type="text" name="person_name" id="person_name" required>

    <label for="date_of_death">Date of Death *</label>
    <input type="date" name="date_of_death" id="date_of_death" required>

    <label for="cause_of_death">Cause of Death</label>
    <input type="text" name="cause_of_death" id="cause_of_death">

    <label for="notes">Notes</label>
    <textarea name="notes" id="notes" rows="3"></textarea>

    <div class="button-row">
        <button type="submit">Save Death Record</button>
        <button type="button" id="clearBtn">Clear</button>
    </div>
</form>

<script>
// vanilla JS fetch-based implementation

const regSelect = document.getElementById('reg_no');
const relationSelect = document.getElementById('relation_select');
const personInput = document.getElementById('person_name');
const clearBtn = document.getElementById('clearBtn');

function resetRelationSelect() {
    relationSelect.innerHTML = '<option value="">-- No relation / choose member --</option>';
    relationSelect.disabled = true;
}

resetRelationSelect();

regSelect.addEventListener('change', function(){
    resetRelationSelect();
    const selectedOption = this.options[this.selectedIndex];
    const memberId = selectedOption ? selectedOption.getAttribute('data-member-id') : null;
    const memberText = selectedOption ? selectedOption.text : '';

    if (!memberId) {
        // not a member selected
        personInput.value = '';
        return;
    }

    // add the member as first option in relation select
    relationSelect.disabled = false;
    relationSelect.innerHTML = '';
    const memberOpt = document.createElement('option');
    memberOpt.value = memberText.replace(/\s*\(.+?\)\s*$/, '').trim(); // member full name (remove reg_no parentheses)
    memberOpt.textContent = 'Member — ' + memberOpt.value;
    relationSelect.appendChild(memberOpt);

    // fetch relations from server
    fetch('get_relations.php?member_id=' + encodeURIComponent(memberId))
        .then(resp => resp.json())
        .then(data => {
            // data expected: array of { id, relation_name, relation_type }
            if (!Array.isArray(data) || data.length === 0) {
                // no relations found - leave only member option
                return;
            }
            data.forEach(rel => {
                const opt = document.createElement('option');
                opt.value = rel.relation_name;
                opt.textContent = rel.relation_name + (rel.relation_type ? ' (' + rel.relation_type + ')' : '');
                relationSelect.appendChild(opt);
            });
        })
        .catch(err => {
            console.error('Relation fetch error:', err);
            // keep just the member option
        });
});

// when relation selected, fill person_name
relationSelect.addEventListener('change', function(){
    const name = this.value || '';
    if (name) personInput.value = name;
});

clearBtn.addEventListener('click', function(){
    document.getElementById('deathForm').reset();
    resetRelationSelect();
});
</script>

</body>
</html>
