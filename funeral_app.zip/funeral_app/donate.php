<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$error = "";
$success = "";

// Fetch death records to select from
$deaths = $conn->query("SELECT d.id, d.person_name, d.date_of_death, m.reg_no, m.full_name 
                        FROM death d 
                        LEFT JOIN members m ON d.reg_no = m.reg_no 
                        ORDER BY d.date_of_death DESC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch inventory items
$items = $conn->query("SELECT id, item_name, current_qty FROM inventory ORDER BY item_name")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $death_id = $_POST['death_id'] ?? null;
    $donation_date = $_POST['donation_date'] ?? date('Y-m-d');
    $amount = floatval($_POST['amount'] ?? 0);

    $donation_qtys = $_POST['donation_qty'] ?? [];

    if (!$death_id) {
        $error = "Please select a death record.";
    } else {
        // Filter only items with donation qty > 0
        $items_to_donate = [];
        foreach ($donation_qtys as $item_id => $qty) {
            $qty = intval($qty);
            if ($qty > 0) {
                $items_to_donate[$item_id] = $qty;
            }
        }

        if (empty($items_to_donate) && $amount <= 0) {
            $error = "Please enter quantity for at least one item or an amount.";
        }
    }

    if (!$error) {
        try {
            // Find member_id from death_id
            $stmt = $conn->prepare("SELECT m.id FROM death d JOIN members m ON d.reg_no = m.reg_no WHERE d.id = ?");
            $stmt->execute([$death_id]);
            $member_id = $stmt->fetchColumn();

            if (!$member_id) {
                throw new Exception("No member linked to this death found.");
            }

            $conn->beginTransaction();

            foreach ($items_to_donate as $item_id => $qty) {
                // Check current qty
                $stmt = $conn->prepare("SELECT current_qty FROM inventory WHERE id = ?");
                $stmt->execute([$item_id]);
                $current_qty = $stmt->fetchColumn();

                if ($current_qty === false) {
                    throw new Exception("Item ID $item_id not found.");
                }

                if ($qty > $current_qty) {
                    throw new Exception("Requested quantity ($qty) exceeds current quantity ($current_qty) for item ID $item_id.");
                }

                // Insert donation record with death_id
                $stmt = $conn->prepare("INSERT INTO donations (member_id, item_id, donation_qty, donation_date, amount, death_id) VALUES (?, ?, ?, ?, ?, ?)");
                // Amount split for multiple items is tricky; 
                // For simplicity, apply full amount to each? Or 0 for items? 
                // Here, 0 amount for items; you can adjust logic as needed
                $stmt->execute([$member_id, $item_id, $qty, $donation_date, 0, $death_id]);

                // Update inventory
                $stmt = $conn->prepare("UPDATE inventory SET current_qty = current_qty - ? WHERE id = ?");
                $stmt->execute([$qty, $item_id]);
            }

            // If amount is > 0, record it as a money donation with item_id = 0 (or NULL)
            if ($amount > 0) {
                $stmt = $conn->prepare("INSERT INTO donations (member_id, item_id, donation_qty, donation_date, amount, death_id) VALUES (?, 0, 0, ?, ?, ?)");
                $stmt->execute([$member_id, $donation_date, $amount, $death_id]);
            }

            $conn->commit();
            $success = "Donations recorded successfully.";
        } catch (Exception $ex) {
            $conn->rollBack();
            $error = "Failed to record donations: " . $ex->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Donate Goods and Money for Death</title>
<style>
/* Keep your CSS from your original Donate.php here */
body { font-family: Arial, sans-serif; max-width: 800px; margin: auto; padding: 20px; background: #f9fafb; }
h1 { color: #2c7be5; text-align: center; }
form { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
label, select, input { display: block; width: 100%; margin-top: 10px; }
input[type=number], input[type=date], select { padding: 6px 10px; border-radius: 6px; border: 1.5px solid #ccc; font-size: 1rem; box-sizing: border-box; }
table { width: 100%; margin-top: 20px; border-collapse: collapse; table-layout: fixed; }
th, td { padding: 10px; border: 1px solid #ddd; text-align: center; vertical-align: middle; word-wrap: break-word; }
th { background-color: #2c7be5; color: white; }
table input[type=number] { width: 80px; padding: 6px 8px; border-radius: 6px; border: 1.5px solid #ccc; font-size: 1rem; box-sizing: border-box; text-align: center; }
button { margin-top: 20px; width: 100%; background-color: #2c7be5; color: white; padding: 14px; font-size: 1.1rem; font-weight: 700; border: none; border-radius: 8px; cursor: pointer; }
button:hover { background-color: #1a5fd3; }
.error { background: #ffe5e5; color: #cc0000; padding: 12px; border-radius: 8px; font-weight: 600; margin-bottom: 20px; text-align: center; }
.success { background: #d6f5d6; color: #2d662d; padding: 12px; border-radius: 8px; font-weight: 600; margin-bottom: 20px; text-align: center; }
/* Responsive */
@media(max-width: 600px) {
    table { display: block; overflow-x: auto; white-space: nowrap; }
}
</style>
</head>
<body>

<h1>Donate Goods and Money for Death</h1>

<?php if (!empty($error)): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if (!empty($success)): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST" novalidate>
    <label for="death_id">Select Death Record</label>
    <select name="death_id" id="death_id" required>
        <option value="" disabled selected>Select Death</option>
        <?php foreach ($deaths as $death): ?>
            <option value="<?= $death['id'] ?>">
                <?= htmlspecialchars($death['person_name'] . " (Died: " . $death['date_of_death'] . ") - Member: " . ($death['full_name'] ?? 'N/A')) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="donation_date">Donation Date</label>
    <input type="date" name="donation_date" id="donation_date" value="<?= date('Y-m-d') ?>" required />

    <label for="amount">Amount (optional)</label>
    <input type="number" min="0" step="0.01" name="amount" id="amount" value="0" />

    <table>
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Current Qty</th>
                <th>Donation Qty</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['item_name']) ?></td>
                <td><?= intval($item['current_qty']) ?></td>
                <td>
                    <input type="number" min="0" name="donation_qty[<?= $item['id'] ?>]" value="0" />
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <button type="submit">Record Donations</button>
</form>

</body>
</html>
