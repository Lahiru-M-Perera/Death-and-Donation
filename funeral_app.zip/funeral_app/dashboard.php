<?php
require "config.php";
checkLogin();

// Fetch dashboard stats
$total_members = $conn->query("SELECT COUNT(*) FROM members")->fetchColumn();
$active_members = $conn->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn();
$inactive_members = $conn->query("SELECT COUNT(*) FROM members WHERE status = 'inactive'")->fetchColumn();

// FIX: Use correct table name 'death'
$deaths_count = $conn->query("SELECT COUNT(*) FROM death")->fetchColumn();

$total_aid_given = $conn->query("SELECT COALESCE(SUM(amount), 0) FROM aids")->fetchColumn();
$total_aid_planned = 100000; // Static example
$total_fine = $conn->query("SELECT COALESCE(SUM(fine_amount), 0) FROM contributions")->fetchColumn();
$total_contrib = $conn->query("SELECT COALESCE(SUM(contribution_amount), 0) FROM contributions")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Dashboard - Funeral Aid System</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
  body { background: #f4f7f9; color: #333; min-height: 100vh; display: flex; flex-direction: column; }
  header { background: #667eea; color: white; padding: 20px 40px; box-shadow: 0 4px 10px rgba(102,126,234,0.4); display: flex; align-items: center; justify-content: space-between; }
  header h1 { font-weight: 700; font-size: 24px; }
  .user-info { font-size: 14px; opacity: 0.85; }
  .user-info a.logout { color: white; text-decoration: none; font-weight: 600; background: rgba(255,255,255,0.2); padding: 6px 14px; border-radius: 6px; margin-left: 15px; transition: background 0.3s; }
  .user-info a.logout:hover { background: rgba(255,255,255,0.4); }
  nav.menu ul { list-style: none; display: flex; gap: 20px; }
  nav.menu ul li a { color: white; text-decoration: none; font-weight: 600; padding: 8px 12px; border-radius: 6px; transition: background 0.3s ease; font-size: 14px; }
  nav.menu ul li a:hover { background: rgba(255,255,255,0.3); }
  main { flex: 1; padding: 30px 40px; }
  .stats-grid { display: grid; grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap: 25px; margin-bottom: 40px; }
  .card { background: white; border-radius: 12px; padding: 25px 20px; box-shadow: 0 8px 18px rgba(0,0,0,0.08); text-align: center; transition: transform 0.3s ease; }
  .card:hover { transform: translateY(-5px); box-shadow: 0 12px 30px rgba(0,0,0,0.12); }
  .card h2 { font-size: 36px; font-weight: 700; color: #667eea; margin-bottom: 8px; }
  .card p { font-size: 16px; font-weight: 600; color: #555; }
  .chart-container { max-width: 600px; margin: 0 auto; background: white; padding: 30px 20px; border-radius: 12px; box-shadow: 0 8px 18px rgba(0,0,0,0.08); }
  .chart-container h3 { text-align: center; margin-bottom: 25px; color: #444; }
  @media(max-width: 600px) {
    nav.menu ul { flex-direction: column; gap: 10px; background: rgba(102,126,234,0.9); position: fixed; top: 60px; right: 20px; padding: 15px; border-radius: 8px; display: none; }
    nav.menu ul.active { display: flex; }
    nav.menu button.menu-toggle { display: inline-block; background: transparent; border: none; color: white; font-size: 24px; cursor: pointer; }
  }
</style>
<script src="assets/js/chart.min.js"></script>
</head>
<body>

<header>
  <div style="display: flex; flex-direction: column; align-items: flex-start;">
    <h1>Dashboard</h1>
    <div class="user-info">Welcome, <?=htmlspecialchars($_SESSION['name'])?></div>
  </div>

  <nav class="menu">
    <button class="menu-toggle" onclick="toggleMenu()"></button>
    <ul id="menu-list">
      <li><a href="members.php">Add Member</a></li>
      <li><a href="relations.php">Add Relation</a></li>
      <li><a href="members_list.php">View Members</a></li>
      <li><a href="relations_list.php">View Relations</a></li>
      <li><a href="deaths_list.php">Deaths</a></li>
      <li><a href="aids_list.php">Aid Records</a></li>
      <li><a href="register.php">Accounts</a></li>
      <li><a href="logout.php" class="logout">Logout</a></li>
    </ul>
  </nav>
</header>

<main>
  <div class="stats-grid">
    <div class="card"><h2><?= $total_members ?></h2><p>Total Members</p></div>
    <div class="card"><h2><?= $active_members ?></h2><p>Active Members</p></div>
    <div class="card"><h2><?= $inactive_members ?></h2><p>Inactive Members</p></div>
    <div class="card"><h2><?= $deaths_count ?></h2><p>Deaths</p></div>
    <div class="card"><h2>Rs. <?= number_format($total_aid_given, 2) ?></h2><p>Total Aid Given</p></div>
    <div class="card"><h2>Rs. <?= number_format($total_aid_planned, 2) ?></h2><p>Total Aid Planned</p></div>
    <div class="card"><h2>Rs. <?= number_format($total_fine, 2) ?></h2><p>Total Fines Collected</p></div>
    <div class="card"><h2>Rs. <?= number_format($total_contrib, 2) ?></h2><p>Total Contributions</p></div>
  </div>

  <div class="chart-container">
    <h3>Member Status Distribution</h3>
    <canvas id="memberStatusChart" width="400" height="300"></canvas>
  </div>
</main>

<script>
function toggleMenu() {
  document.getElementById('menu-list').classList.toggle('active');
}
const ctx = document.getElementById('memberStatusChart').getContext('2d');
new Chart(ctx, {
  type: 'pie',
  data: {
    labels: ['Active Members', 'Inactive Members', 'Deaths'],
    datasets: [{
      data: [<?= $active_members ?>, <?= $inactive_members ?>, <?= $deaths_count ?>],
      backgroundColor: ['rgba(102, 126, 234, 0.7)', 'rgba(255, 206, 86, 0.7)', 'rgba(255, 99, 132, 0.7)'],
      borderColor: 'white', borderWidth: 2
    }]
  },
  options: {
    responsive: true,
    plugins: { legend: { position: 'bottom', labels: { font: { size: 14 } } } }
  }
});
</script>

</body>
</html>
