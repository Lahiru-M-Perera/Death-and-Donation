<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $name = trim($_POST['name']);
    $role = $_POST['role'] ?? 'user';
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Basic validation
    if (empty($username) || empty($name) || empty($password) || empty($confirm_password)) {
        $error = "Please fill in all required fields.";
    } elseif (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username)) {
        $error = "Username must be 3-50 characters and contain only letters, numbers, and underscores.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } elseif (!in_array($role, ['admin', 'user'])) {
        $error = "Invalid role selected.";
    } else {
        // Check if username exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = "Username already exists, please choose another.";
        } else {
            // Insert password as plain text (NO HASHING)
            $stmt = $conn->prepare("INSERT INTO users (username, password, role, name) VALUES (?, ?, ?, ?)");
            try {
                $stmt->execute([$username, $password, $role, $name]);
                $success = "User account created successfully!";
            } catch (PDOException $ex) {
                $error = "Database error: " . $ex->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Create User Account</title>
<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f7f9fc;
    margin: 0;
    padding: 40px 20px;
    color: #333;
  }
  .container {
    max-width: 450px;
    margin: 0 auto;
    background: #fff;
    padding: 30px 35px;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  }
  h1 {
    text-align: center;
    color: #2c3e50;
    margin-bottom: 25px;
    font-weight: 700;
  }
  label {
    display: block;
    margin-top: 18px;
    font-weight: 600;
    color: #555;
  }
  input[type="text"],
  select {
    width: 100%;
    padding: 10px 14px;
    margin-top: 6px;
    border-radius: 6px;
    border: 1.5px solid #ccc;
    font-size: 1rem;
    font-family: inherit;
    transition: border-color 0.3s ease;
  }
  input[type="text"]:focus,
  select:focus {
    border-color: #2c7be5;
    outline: none;
    box-shadow: 0 0 6px rgba(44,123,229,0.4);
  }
  button {
    margin-top: 30px;
    width: 100%;
    padding: 14px 0;
    background-color: #2c7be5;
    color: white;
    font-size: 18px;
    font-weight: 700;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  button:hover {
    background-color: #1a5fd3;
  }
  .error, .success {
    margin-bottom: 20px;
    padding: 12px 18px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 1rem;
    text-align: center;
    user-select: none;
  }
  .error {
    background-color: #ffe5e5;
    color: #cc0000;
    border: 1px solid #cc0000;
  }
  .success {
    background-color: #d6f5d6;
    color: #2d662d;
    border: 1px solid #2d662d;
  }
  @media(max-width: 480px) {
    .container {
      margin: 50px 15px;
      padding: 25px 20px;
    }
  }
</style>
</head>
<body>
<div class="container">
  <h1>Create User Account</h1>

  <?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if ($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>

  <form method="POST" novalidate>
    <label for="username">Username *</label>
    <input type="text" id="username" name="username" required pattern="[a-zA-Z0-9_]{3,50}" 
      title="3-50 characters, letters, numbers, and underscores only" autocomplete="off" />

    <label for="name">Full Name *</label>
    <input type="text" id="name" name="name" required autocomplete="off" />

    <label for="role">Role *</label>
    <select id="role" name="role" required>
      <option value="" disabled selected>Select role</option>
      <option value="user">User</option>
      <option value="admin">Admin</option>
    </select>

    <label for="password">Password *</label>
    <input type="text" id="password" name="password" required minlength="6" autocomplete="off" />

    <label for="confirm_password">Confirm Password *</label>
    <input type="text" id="confirm_password" name="confirm_password" required minlength="6" autocomplete="off" />

    <button type="submit">Register</button>
  </form>
</div>

<script>
  // Client-side password match validation
  const form = document.querySelector('form');
  form.addEventListener('submit', function(event) {
    const pw = document.getElementById('password').value;
    const cpw = document.getElementById('confirm_password').value;
    if (pw !== cpw) {
      alert('Passwords do not match!');
      event.preventDefault();
    }
  });
</script>
</body>
</html>
