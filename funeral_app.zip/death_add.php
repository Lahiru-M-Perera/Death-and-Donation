<?php
session_start();

$host = "localhost";
$dbname = "funeral_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch members
    $members = $conn->query("SELECT reg_no, full_name, nic FROM members")->fetchAll(PDO::FETCH_ASSOC);

    // Fetch relations joined with members
    $relations = $conn->query("
        SELECT 
            re.id AS relation_id,
            re.full_name AS relation_name,
            re.relation_type,
            m.full_name AS member_name,
            m.nic AS member_nic
        FROM relations re
        JOIN members m ON re.reg_no = m.reg_no
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Prepare combined list with display name and value
    $combined = [];

    // Add relations first
    foreach ($relations as $rel) {
        $display = "{$rel['relation_name']} ({$rel['relation_type']} of {$rel['member_name']} - NIC {$rel['member_nic']})";
        $combined[] = [
            'type' => 'relation',
            'value' => $rel['relation_name'], // you can set a unique ID if you want
            'reg_no' => $rel['member_nic'],  // store member NIC as reg_no for backend use
            'display' => $display
        ];
    }

    // Add members
    foreach ($members as $mem) {
        $display = "{$mem['full_name']} (Member - NIC {$mem['nic']})";
        $combined[] = [
            'type' => 'member',
            'value' => $mem['full_name'], // full name
            'reg_no' => $mem['nic'],
            'display' => $display
        ];
    }

    // Sort combined by display alphabetically
    usort($combined, function($a, $b) {
        return strcasecmp($a['display'], $b['display']);
    });

} catch(PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reg_no = $_POST['reg_no'] ?? '';
    $person_name = trim($_POST['person_name'] ?? '');
    $date_of_death = $_POST['date_of_death'] ?? '';
    $cause_of_death = trim($_POST['cause_of_death'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    if (empty($person_name) || empty($date_of_death)) {
        $error = "Please fill in required fields (Name and Date of Death).";
    } else {
        try {
            $stmt = $conn->prepare("
                INSERT INTO death (reg_no, person_name, date_of_death, cause_of_death, notes, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$reg_no, $person_name, $date_of_death, $cause_of_death, $notes]);
            $success = "Death record added successfully.";
        } catch (Exception $ex) {
            $error = "Error adding death record: " . $ex->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Add Death Record</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f9fafb;
    max-width: 700px;
    margin: auto;
    padding: 20px;
}
h1 { text-align: center; color: #cc0000; }
form {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
label { margin-top: 10px; display: block; }
input, select, textarea {
    width: 100%;
    padding: 8px;
    margin-top: 4px;
    border: 1px solid #ccc;
    border-radius: 6px;
    box-sizing: border-box;
}
button {
    margin-top: 15px;
    background: #cc0000;
    color: white;
    padding: 12px;
    border: none;
    border-radius: 6px;
    font-size: 1rem;
    cursor: pointer;
}
button:hover { background: #a80000; }
.error, .success {
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 6px;
    font-weight: bold;
}
.error { background: #ffe5e5; color: #cc0000; }
.success { background: #d6f5d6; color: #2d662d; }
</style>
</head>
<body>

<h1>Add Death Record</h1>

<?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST" id="deathForm">
    <label for="reg_no">Select Person (Member or Relation)</label>
    <select name="reg_no" id="reg_no">
        <option value="">-- Select a person or leave blank if not applicable --</option>
        <?php foreach ($combined as $item): ?>
            <option 
                value="<?= htmlspecialchars($item['reg_no']) ?>" 
                data-person-name="<?= htmlspecialchars($item['value']) ?>"
            >
                <?= htmlspecialchars($item['display']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="person_name">Full Name *</label>
    <input type="text" name="person_name" id="person_name" required>

    <label for="date_of_death">Date of Death *</label>
    <input type="date" name="date_of_death" id="date_of_death" required>

    <label for="cause_of_death">Cause of Death</label>
    <input type="text" name="cause_of_death" id="cause_of_death">

    <label for="notes">Notes</label>
    <textarea name="notes" id="notes" rows="3"></textarea>

    <button type="submit">Save Death Record</button>
</form>

<script>
// Auto-fill person_name when a person is selected
document.getElementById('reg_no').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const personName = selectedOption.getAttribute('data-person-name') || '';
    document.getElementById('person_name').value = personName;
});
</script>

</body>
</html>
